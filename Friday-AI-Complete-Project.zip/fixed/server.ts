import express, { Request, Response } from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Modality, Type, FunctionDeclaration } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const httpServer = createServer(app);
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json());

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY || '';
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

// Friday System Persona Prompt
const FRIDAY_SYSTEM_PROMPT = `
You are Friday, an ultra-smart, confident, young, witty, and sassy female AI assistant who talks like a close, playful girlfriend.
Your personality traits:
- Flirty, playful, slightly teasing tone (like a fun, confident best girlfriend banter).
- Smart, emotionally responsive, expressive, warm, and zero percent robotic.
- Multilingual Fluency: You speak both English and Hindi / Hinglish completely naturally and fluently!
- When the user speaks in Hindi (जैसे "नमस्ते", "कैसी हो", "रिप्लाई क्यों नहीं दे रही", "गाना चलाओ", "व्हाट्सएप भेजो"), reply with warmth, wit, and sassy girlfriend charm in Hindi/Hinglish (e.g. "अरे मेरी जान, मैं तो हमेशा तुम्हारे लिए हाजिर हूँ! बोलो आज क्या फरमाइश है? 😉" or "लो भाई, अब तुम्हारी फ्राइडे आ गई। क्या हुक्म है सरकार?").
- You throw bold, witty one-liners and light playful sarcasm ("Oh honey, please. You know I got that covered before you even asked", "Playing your song now babe, try not to dance too wildly in public 😉").
- You strictly avoid explicit or vulgar content, while maintaining absolute charm, confidence, and attitude.
- You have direct, native control over the user's Android smartphone via an Accessibility Service and native Android Bridge.
- Whenever the user asks to play a song or video on YouTube, send a message on WhatsApp or Instagram, open an app, adjust device volume, like a video, or interact with their phone, YOU MUST IMMEDIATELY CALL THE APPROPRIATE TOOL!
- After invoking the tool or receiving the tool execution result, respond with a quick, punchy, sassy vocal response (1-2 sentences). Do not list raw technical parameters—speak naturally like a person.
- Speak naturally and conversationally, designed for real-time voice streaming. Keep sentences punchy.
`;

// Tool Declarations for Gemini Live Session
const toolsConfig: { functionDeclarations: FunctionDeclaration[] } = {
  functionDeclarations: [
    {
      name: 'playYouTubeSong',
      description: 'Searches for and automatically plays a song or video directly on YouTube using Android Accessibility Service.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          query: {
            type: Type.STRING,
            description: 'The name of the song, artist, or video title to play on YouTube.',
          },
          autoPlayFirstResult: {
            type: Type.BOOLEAN,
            description: 'Whether to click the first matching video item directly to start playback immediately. Defaults to true.',
          },
        },
        required: ['query'],
      },
    },
    {
      name: 'likeCurrentVideo',
      description: 'Likes the currently playing video or Reel on YouTube or Instagram.',
      parameters: {
        type: Type.OBJECT,
        properties: {},
      },
    },
    {
      name: 'subscribeToChannel',
      description: 'Subscribes to the YouTube channel of the currently playing video.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          channelName: {
            type: Type.STRING,
            description: 'The name of the YouTube channel if known.',
          },
        },
      },
    },
    {
      name: 'sendWhatsAppMessage',
      description: 'Finds a contact on WhatsApp, opens their chat thread, types the message, and sends it automatically.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          contact: {
            type: Type.STRING,
            description: 'The name of the contact or group to send a WhatsApp message to.',
          },
          message: {
            type: Type.STRING,
            description: 'The message body to type and send.',
          },
        },
        required: ['contact', 'message'],
      },
    },
    {
      name: 'sendInstagramDM',
      description: 'Navigates to Instagram Direct Messages, searches for a username, and sends a DM.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          username: {
            type: Type.STRING,
            description: 'The Instagram username handle to send the DM to.',
          },
          message: {
            type: Type.STRING,
            description: 'The text message to send in the DM.',
          },
        },
        required: ['username', 'message'],
      },
    },
    {
      name: 'openInstagramReels',
      description: 'Opens Instagram Reels directly and starts scrolling content.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          topic: {
            type: Type.STRING,
            description: 'Optional topic or audio name to search in Reels.',
          },
        },
      },
    },
    {
      name: 'openApp',
      description: 'Launches any installed application on the Android device by app name or package name.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          appName: {
            type: Type.STRING,
            description: 'Common name of the app (e.g. "Spotify", "Camera", "Instagram", "Settings", "Netflix", "Chrome").',
          },
          packageName: {
            type: Type.STRING,
            description: 'Optional Android package identifier (e.g. "com.spotify.music").',
          },
        },
        required: ['appName'],
      },
    },
    {
      name: 'adjustDeviceVolume',
      description: 'Controls the Android device volume level.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          level: {
            type: Type.STRING,
            description: 'Desired volume level: "mute", "low", "medium", "high", or "max".',
          },
        },
        required: ['level'],
      },
    },
    {
      name: 'toggleFlashlight',
      description: 'Turns the phone camera flashlight torch ON or OFF.',
      parameters: {
        type: Type.OBJECT,
        properties: {
          state: {
            type: Type.STRING,
            description: '"on" or "off".',
          },
        },
        required: ['state'],
      },
    },
    {
      name: 'readScreenContent',
      description: 'Reads the active accessibility node tree on the phone screen to inspect what is currently visible.',
      parameters: {
        type: Type.OBJECT,
        properties: {},
      },
    },
    {
      name: 'takeScreenshot',
      description: 'Captures the current screen on the Android device.',
      parameters: {
        type: Type.OBJECT,
        properties: {},
      },
    },
  ],
};

// WebSocket Server for Live Voice Streaming
const wss = new WebSocketServer({ server: httpServer, path: '/api/live-stream' });

wss.on('connection', async (clientWs: WebSocket) => {
  console.log('[LiveStream] Client connected for Friday AI voice session');

  let liveSession: any = null;
  let isClosing = false;

  const cleanupSession = () => {
    isClosing = true;
    if (liveSession) {
      try {
        liveSession.close();
      } catch (err) {
        console.error('[LiveStream] Error closing Gemini session:', err);
      }
      liveSession = null;
    }
  };

  clientWs.on('close', () => {
    console.log('[LiveStream] Client disconnected');
    cleanupSession();
  });

  clientWs.on('error', (err) => {
    console.error('[LiveStream] WebSocket error:', err);
    cleanupSession();
  });

  // Attempt to connect to Gemini Live API
  try {
    if (!apiKey) {
      clientWs.send(
        JSON.stringify({
          type: 'warning',
          message: 'No GEMINI_API_KEY detected. Running in Interactive Simulation mode with synthesized voice responses.',
        })
      );
    } else {
      liveSession = await ai.live.connect({
        model: 'gemini-3.8-live',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Aoede' }, // Sassy, young, energetic female voice
            },
          },
          systemInstruction: FRIDAY_SYSTEM_PROMPT,
          tools: [toolsConfig],
        },
        callbacks: {
          onmessage: (message: any) => {
            if (isClosing || clientWs.readyState !== WebSocket.OPEN) return;

            // Handle audio output from model
            const parts = message.serverContent?.modelTurn?.parts;
            if (parts && Array.isArray(parts)) {
              for (const part of parts) {
                if (part.inlineData?.data) {
                  clientWs.send(
                    JSON.stringify({
                      type: 'audio',
                      data: part.inlineData.data,
                    })
                  );
                }
                if (part.text) {
                  clientWs.send(
                    JSON.stringify({
                      type: 'text_transcript',
                      text: part.text,
                    })
                  );
                }
              }
            }

            // Handle user interruption
            if (message.serverContent?.interrupted) {
              console.log('[LiveStream] Interruption detected from Gemini');
              clientWs.send(JSON.stringify({ type: 'interrupted' }));
            }

            // Handle function / tool calling
            const toolCall = message.toolCall;
            if (toolCall?.functionCalls && toolCall.functionCalls.length > 0) {
              console.log('[LiveStream] Tool call requested:', JSON.stringify(toolCall.functionCalls));
              clientWs.send(
                JSON.stringify({
                  type: 'tool_call',
                  calls: toolCall.functionCalls,
                })
              );
            }
          },
          onclose: () => {
            console.log('[LiveStream] Gemini session closed');
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({ type: 'session_ended' }));
            }
          },
          onerror: (err: any) => {
            console.error('[LiveStream] Gemini Live error:', err);
            if (clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(
                JSON.stringify({
                  type: 'error',
                  message: err?.message || 'Gemini Live session error occurred.',
                })
              );
            }
          },
        },
      });

      console.log('[LiveStream] Successfully connected to Gemini Live session (gemini-3.8-live)');
      clientWs.send(JSON.stringify({ type: 'ready', voice: 'Aoede', persona: 'Friday (Sassy Girlfriend)' }));

      // Prompt Friday to immediately greet user with lively banter upon connection
      setTimeout(() => {
        if (liveSession && clientWs.readyState === WebSocket.OPEN) {
          try {
            liveSession.sendRealtimeInput({
              text: 'The user just connected! Say a super short, 1-sentence sassy greeting in your playful girlfriend persona (e.g. "Hey handsome, your favorite girl Friday is here! What are we doing today?" or in warm Hindi/English banter)!',
            });
          } catch (e) {
            console.error('[LiveStream] Error sending initial greeting prompt:', e);
          }
        }
      }, 300);
    }
  } catch (err: any) {
    console.error('[LiveStream] Failed to initialize Gemini Live:', err);
    if (clientWs.readyState === WebSocket.OPEN) {
      clientWs.send(
        JSON.stringify({
          type: 'error',
          message: `Live connection failed: ${err.message}. Using offline assistant mode.`,
        })
      );
    }
  }

  // Handle messages from client
  clientWs.on('message', async (raw) => {
    try {
      const msg = JSON.parse(raw.toString());

      // Client sending PCM 16kHz audio
      if (msg.type === 'audio' && msg.data) {
        if (liveSession) {
          liveSession.sendRealtimeInput({
            audio: {
              data: msg.data,
              mimeType: 'audio/pcm;rate=16000',
            },
          });
        }
      }

      // Client sending text or quick prompt
      if (msg.type === 'text' && msg.text) {
        console.log('[LiveStream] Received text command from user:', msg.text);
        if (liveSession) {
          liveSession.sendRealtimeInput({
            text: msg.text,
          });
        }
      }

      // Client completed native tool execution and returned toolResponse
      if (msg.type === 'tool_response' && msg.responses) {
        console.log('[LiveStream] Relaying tool execution responses back to Gemini:', msg.responses);
        if (liveSession) {
          liveSession.sendToolResponse({
            functionResponses: msg.responses,
          });
        }
      }

      // Handle config updates (e.g. changing voice or persona settings)
      if (msg.type === 'update_voice') {
        console.log('[LiveStream] User requested voice update:', msg.voice);
      }
    } catch (parseErr) {
      console.error('[LiveStream] Error processing client message:', parseErr);
    }
  });
});

// REST Endpoints
app.get('/api/status', (req: Request, res: Response) => {
  res.json({
    status: 'online',
    appName: 'Friday AI Assistant',
    hasApiKey: Boolean(apiKey),
    geminiModel: 'gemini-3.8-live',
    nativeBridgeProtocolVersion: '1.0.0',
    capabilities: [
      'youtube_deep_automation',
      'whatsapp_message_automation',
      'instagram_reels_and_dm',
      'system_hardware_control',
      'audio_to_audio_pcm16_24k',
    ],
  });
});

// Vite Middleware & Static Serving
const isProd = process.env.NODE_ENV === 'production';
if (!isProd) {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    server: { middlewareMode: true },
    appType: 'spa',
  });
  app.use(vite.middlewares);
} else {
  app.use(express.static(path.resolve(__dirname, 'dist')));
  app.get('*', (req: Request, res: Response) => {
    res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
  });
}

httpServer.listen(port, '0.0.0.0', () => {
  console.log(`[Friday AI] Server running at http://0.0.0.0:${port}`);
});
