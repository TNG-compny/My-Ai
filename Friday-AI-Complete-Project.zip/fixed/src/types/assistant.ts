export type AssistantState =
  | 'disconnected'
  | 'connecting'
  | 'listening'
  | 'thinking'
  | 'speaking'
  | 'executing_action'
  | 'error';

export interface ToolCallItem {
  id: string;
  name: string;
  args: Record<string, any>;
}

export interface ToolResponseItem {
  id: string;
  name: string;
  response: {
    output: Record<string, any>;
  };
}

export interface AutomationStep {
  id: string;
  title: string;
  detail: string;
  status: 'pending' | 'in_progress' | 'done' | 'failed';
  timestamp?: number;
}

export interface ActionTrace {
  id: string;
  app: 'youtube' | 'whatsapp' | 'instagram' | 'system' | 'spotify' | 'general';
  actionName: string;
  title: string;
  subtitle: string;
  steps: AutomationStep[];
  status: 'executing' | 'completed' | 'failed';
  timestamp: number;
  sassyCommentary?: string;
  simulatedNodeTree?: {
    viewId?: string;
    text?: string;
    action?: string;
  }[];
}

export interface AndroidBridgeInterface {
  isAccessibilityServiceEnabled: () => boolean;
  hasOverlayPermission: () => boolean;
  hasNotificationPermission: () => boolean;
  openAccessibilitySettings: () => void;
  openOverlaySettings: () => void;
  openNotificationSettings: () => void;
  openApp: (packageNameOrName: string) => string;
  playYouTubeSong: (query: string, autoPlay: boolean) => string;
  likeCurrentVideo: () => string;
  subscribeToChannel: (channelName?: string) => string;
  sendWhatsAppMessage: (contact: string, message: string) => string;
  sendInstagramDM: (username: string, message: string) => string;
  adjustVolume: (level: string) => boolean;
  toggleFlashlight: (state: boolean) => boolean;
  readScreenContent: () => string;
  takeScreenshot: () => string;
  getDeviceInfo: () => string;
  getServerUrl: () => string;
}

declare global {
  interface Window {
    AndroidBridge?: AndroidBridgeInterface;
  }
}
