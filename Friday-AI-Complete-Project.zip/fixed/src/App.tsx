import React, { useState, useEffect } from 'react';
import {
  Mic,
  ShieldCheck,
  Smartphone,
  Settings as SettingsIcon,
  Terminal,
  Volume2,
  VolumeX,
  Sparkles,
  Youtube,
  MessageCircle,
  Instagram,
  Radio,
  Layers,
  ChevronRight,
  Flame,
  Send,
  Languages,
} from 'lucide-react';
import { HolographicCore } from './components/HolographicCore';
import { AudioWaveformVisualizer } from './components/AudioWaveformVisualizer';
import { ActionHud } from './components/ActionHud';
import { PermissionModal } from './components/PermissionModal';
import { AutomationDebuggerModal } from './components/AutomationDebuggerModal';
import { AndroidCompanionModal } from './components/AndroidCompanionModal';
import { SettingsModal } from './components/SettingsModal';
import { liveSession } from './services/liveSession';
import { nativeBridge } from './services/nativeBridge';
import { AssistantState } from './types/assistant';

export default function App() {
  const [state, setState] = useState<AssistantState>('disconnected');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [currentVoice, setCurrentVoice] = useState('Aoede');
  const [liveTranscript, setLiveTranscript] = useState<{ speaker: 'user' | 'friday'; text: string } | null>(null);
  const [customInput, setCustomInput] = useState('');

  // Modals
  const [isPermModalOpen, setIsPermModalOpen] = useState(false);
  const [isDebuggerOpen, setIsDebuggerOpen] = useState(false);
  const [isCompanionOpen, setIsCompanionOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  // Suggested Voice Commands (English & Hindi)
  const quickVoicePrompts = [
    { label: 'गाना चलाओ (YouTube)', icon: <Youtube className="w-3.5 h-3.5 text-red-400" />, action: () => liveSession.sendTextMessage('यूट्यूब पर कोई मस्त गाना चलाओ') },
    { label: 'Play "Starboy" (YouTube)', icon: <Youtube className="w-3.5 h-3.5 text-red-400" />, action: () => liveSession.sendTextMessage('Play Starboy on YouTube') },
    { label: 'कैसी हो फ्राइडे? 😉', icon: <Sparkles className="w-3.5 h-3.5 text-pink-400" />, action: () => liveSession.sendTextMessage('अरे फ्राइडे, कैसी हो तुम?') },
    { label: 'WhatsApp: "Meet at 6 PM?"', icon: <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />, action: () => liveSession.sendTextMessage('Send a WhatsApp message to Sarah saying Are we still meeting at 6 PM?') },
    { label: 'Instagram DM @sarah', icon: <Instagram className="w-3.5 h-3.5 text-pink-400" />, action: () => liveSession.sendTextMessage('Send Instagram DM to Sarah saying Loved your latest post!') },
    { label: 'Launch Spotify App', icon: <Smartphone className="w-3.5 h-3.5 text-green-400" />, action: () => liveSession.sendTextMessage('Open Spotify') },
  ];

  useEffect(() => {
    const unsubState = liveSession.subscribeState((newState) => {
      setState(newState);
      if (newState !== 'error') {
        setErrorMessage(null);
      }
    });

    const unsubError = liveSession.subscribeError((err) => {
      setErrorMessage(err);
    });

    const unsubTranscript = liveSession.subscribeTranscript((t) => {
      setLiveTranscript(t);
    });

    // Check permissions on mount
    const perms = nativeBridge.checkPermissions();
    if (!perms.accessibility) {
      const seen = localStorage.getItem('friday_perms_seen');
      if (!seen) {
        setIsPermModalOpen(true);
        localStorage.setItem('friday_perms_seen', 'true');
      }
    }

    return () => {
      unsubState();
      unsubError();
      unsubTranscript();
    };
  }, []);

  const handleToggleConnect = async () => {
    if (state === 'disconnected' || state === 'error') {
      await liveSession.connect();
    } else {
      liveSession.disconnect();
    }
  };

  const handleSendCustomText = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customInput.trim()) return;
    liveSession.sendTextMessage(customInput.trim());
    setCustomInput('');
  };

  return (
    <div className="relative min-h-screen w-full bg-[#030612] text-slate-100 flex flex-col justify-between overflow-hidden select-none hologram-grid">
      {/* Background ambient neon glow fields */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[460px] h-[460px] bg-gradient-to-tr from-cyan-600/15 via-purple-600/10 to-pink-600/15 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-10 -right-20 w-80 h-80 bg-pink-600/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute top-10 -left-20 w-80 h-80 bg-cyan-600/10 rounded-full blur-[100px] pointer-events-none" />

      {/* Action HUD Overlay (Floating Cyber Banner during native automation) */}
      <ActionHud />

      {/* Top Futuristic Navigation Bar */}
      <header className="relative z-20 px-4 sm:px-6 py-4 flex items-center justify-between border-b border-slate-800/80 bg-slate-950/40 backdrop-blur-xl">
        {/* Brand & Sassy Persona Identity */}
        <div className="flex items-center gap-3">
          <div className="relative flex items-center justify-center w-10 h-10 rounded-2xl bg-gradient-to-br from-cyan-500 via-sky-500 to-pink-500 p-[1.5px] shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-pink-400 animate-pulse" />
            </div>
            <div className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-slate-950" />
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-extrabold tracking-tight text-white font-display">
                FRIDAY
              </h1>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-pink-500/15 text-pink-300 border border-pink-500/30 font-semibold tracking-wider">
                V3.8 LIVE
              </span>
            </div>
            <p className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <span>English & हिंदी / Hinglish</span>
              <span className="text-slate-600">•</span>
              <span className="text-cyan-400 font-medium">Real-Time Voice</span>
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Permissions Hub */}
          <button
            onClick={() => setIsPermModalOpen(true)}
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/50 text-slate-300 hover:text-cyan-300 transition-all flex items-center gap-1.5 text-xs font-semibold"
            title="Android Accessibility Permissions"
          >
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span className="hidden sm:inline">Permissions</span>
          </button>

          {/* Native Automation Debugger */}
          <button
            onClick={() => setIsDebuggerOpen(true)}
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-cyan-500/50 text-slate-300 hover:text-cyan-300 transition-all flex items-center gap-1.5 text-xs font-semibold"
            title="Inspect Automation Events"
          >
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span className="hidden sm:inline">Automation</span>
          </button>

          {/* Android APK Companion */}
          <button
            onClick={() => setIsCompanionOpen(true)}
            className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-purple-500/50 text-slate-300 hover:text-purple-300 transition-all flex items-center gap-1.5 text-xs font-semibold"
            title="Android APK Wrapper & Bridge Sources"
          >
            <Smartphone className="w-4 h-4 text-purple-400" />
            <span className="hidden sm:inline">APK</span>
          </button>

          {/* Settings */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="p-2 rounded-xl bg-slate-900/80 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white transition-all"
            title="Voice & Persona Settings"
          >
            <SettingsIcon className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Error Alert Banner */}
      {errorMessage && (
        <div className="relative z-30 mx-4 mt-3 max-w-md self-center px-4 py-2.5 rounded-2xl bg-rose-950/80 border border-rose-500/40 text-xs text-rose-200 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
            <p>{errorMessage}</p>
          </div>
          <button
            onClick={() => setErrorMessage(null)}
            className="ml-3 text-rose-400 hover:text-rose-200 font-bold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Main Center Area: Holographic Core */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 py-1">
        {/* Holographic Core & Voice Reactor */}
        <HolographicCore
          state={state}
          onToggleConnect={handleToggleConnect}
          voiceName={currentVoice}
        />

        {/* Real-time Audio Waveform */}
        <div className="w-full max-w-sm px-6 mt-1">
          <AudioWaveformVisualizer state={state} />
        </div>

        {/* Live Caption / Transcript Bubble */}
        {liveTranscript && (
          <div className="mt-2 max-w-sm px-4 py-1.5 rounded-xl bg-slate-950/70 border border-slate-800 text-xs text-slate-300 flex items-center gap-2 animate-fadeIn">
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-pink-500/20 text-pink-300 uppercase shrink-0">
              {liveTranscript.speaker === 'friday' ? 'Friday' : 'You'}
            </span>
            <span className="truncate italic">"{liveTranscript.text}"</span>
          </div>
        )}

        {/* Dynamic Voice Hint Banner */}
        <div className="mt-2 text-center">
          <p className="text-xs text-slate-400 flex items-center justify-center gap-1.5 font-medium">
            <Radio className="w-3.5 h-3.5 text-pink-400 animate-pulse" />
            <span>Speak or type freely in English or हिंदी (बोलें या टाइप करें)</span>
          </p>
        </div>
      </main>

      {/* Bottom Tray: Quick Voice Triggers & Fast Action Composer */}
      <footer className="relative z-20 pb-5 pt-2 px-4 max-w-xl mx-auto w-full">
        {/* Fast Text/Voice Input fallback */}
        <form onSubmit={handleSendCustomText} className="mb-2.5 flex items-center gap-2">
          <input
            type="text"
            value={customInput}
            onChange={(e) => setCustomInput(e.target.value)}
            placeholder="बोलें या टाइप करें (e.g. गाना चलाओ, कैसी हो?)"
            className="flex-1 px-3.5 py-2 rounded-xl bg-slate-900/80 border border-slate-800 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-cyan-500/60 shadow-inner"
          />
          <button
            type="submit"
            className="p-2 rounded-xl bg-gradient-to-r from-cyan-500 to-sky-500 text-slate-950 font-bold hover:opacity-90 active:scale-95 transition-all shadow-md shadow-cyan-500/20"
            title="Send to Friday"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        <div className="flex items-center justify-between px-2 mb-1.5 text-[11px] font-mono text-slate-400">
          <span className="flex items-center gap-1.5">
            <Flame className="w-3.5 h-3.5 text-amber-400" />
            <span>Quick Voice Prompts</span>
          </span>
          <span className="text-slate-500">Tap to speak/execute</span>
        </div>

        {/* Grid of quick voice prompts */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
          {quickVoicePrompts.map((prompt, i) => (
            <button
              key={i}
              onClick={prompt.action}
              className="p-2 rounded-xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-cyan-500/40 text-left transition-all group flex items-center justify-between shadow-sm active:scale-98"
            >
              <div className="flex items-center gap-1.5 truncate">
                <div className="p-1 rounded-lg bg-slate-950 border border-slate-800 shrink-0">
                  {prompt.icon}
                </div>
                <span className="text-[11px] font-semibold text-slate-300 group-hover:text-cyan-200 truncate">
                  {prompt.label}
                </span>
              </div>
              <ChevronRight className="w-3 h-3 text-slate-600 group-hover:text-cyan-400 shrink-0" />
            </button>
          ))}
        </div>

        {/* Device Status Bar */}
        <div className="mt-2.5 flex items-center justify-between px-3 py-1 rounded-xl bg-slate-950/70 border border-slate-800/60 text-[10px] font-mono text-slate-400">
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>Accessibility: ACTIVE</span>
          </div>
          <div className="flex items-center gap-2">
            <span>Bridge: OK</span>
            <span className="text-slate-600">|</span>
            <span className="text-cyan-400">PCM 16k/24k</span>
          </div>
        </div>
      </footer>

      {/* Modals */}
      <PermissionModal
        isOpen={isPermModalOpen}
        onClose={() => setIsPermModalOpen(false)}
      />

      <AutomationDebuggerModal
        isOpen={isDebuggerOpen}
        onClose={() => setIsDebuggerOpen(false)}
      />

      <AndroidCompanionModal
        isOpen={isCompanionOpen}
        onClose={() => setIsCompanionOpen(false)}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        currentVoice={currentVoice}
        onSelectVoice={(v) => setCurrentVoice(v)}
      />
    </div>
  );
}
