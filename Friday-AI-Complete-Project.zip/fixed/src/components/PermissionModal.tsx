import React, { useState, useEffect } from 'react';
import { ShieldCheck, Layers, Mic, Bell, ExternalLink, Check, AlertTriangle, X, Sparkles } from 'lucide-react';
import { nativeBridge } from '../services/nativeBridge';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const PermissionModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [perms, setPerms] = useState(nativeBridge.checkPermissions());

  useEffect(() => {
    if (isOpen) {
      setPerms(nativeBridge.checkPermissions());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleToggle = (key: 'accessibility' | 'overlay' | 'notifications') => {
    if (perms.isNativeBridge) {
      nativeBridge.openSettings(key);
    } else {
      nativeBridge.toggleSimulatedPermission(key);
      setPerms(nativeBridge.checkPermissions());
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="cyber-panel rounded-3xl p-6 w-full max-w-md border border-cyan-500/40 relative shadow-2xl overflow-hidden">
        {/* Futuristic glowing corner accents */}
        <div className="absolute top-0 right-0 w-28 h-28 bg-gradient-to-br from-cyan-500/20 to-transparent rounded-bl-full pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-28 h-28 bg-gradient-to-tr from-pink-500/20 to-transparent rounded-tr-full pointer-events-none" />

        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-400">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 font-display">
                Android Permissions Hub
              </h3>
              <p className="text-xs text-slate-400">
                Grant native access for Friday's automation
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-xl hover:bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Persona tip */}
        <div className="mt-4 p-3 rounded-2xl bg-gradient-to-r from-pink-950/30 to-purple-950/30 border border-pink-500/25 flex items-start gap-2.5">
          <Sparkles className="w-4 h-4 text-pink-400 shrink-0 mt-0.5" />
          <p className="text-xs text-pink-200 leading-relaxed">
            "To let me play YouTube songs, slide into DMs, and take control of your phone like a real girlfriend, I need these permissions enabled babe!"
          </p>
        </div>

        {/* Permissions List */}
        <div className="mt-5 space-y-3">
          {/* Accessibility Service */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-purple-950/60 border border-purple-500/30 text-purple-400">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-slate-200">Accessibility Service</h4>
                <p className="text-[11px] text-slate-400">
                  Auto-click YouTube, type WhatsApp/IG messages
                </p>
              </div>
            </div>
            <button
              onClick={() => handleToggle('accessibility')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                perms.accessibility
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30'
              }`}
            >
              {perms.accessibility ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Granted</span>
                </>
              ) : (
                <>
                  <span>Enable</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>

          {/* Draw Over Apps (Overlay) */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-cyan-400">
                <Layers className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-slate-200">Draw Over Other Apps</h4>
                <p className="text-[11px] text-slate-400">
                  Display floating Friday orb over YouTube & apps
                </p>
              </div>
            </div>
            <button
              onClick={() => handleToggle('overlay')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                perms.overlay
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30'
              }`}
            >
              {perms.overlay ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Granted</span>
                </>
              ) : (
                <>
                  <span>Enable</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>

          {/* Microphone */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-pink-950/60 border border-pink-500/30 text-pink-400">
                <Mic className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-slate-200">Microphone Audio</h4>
                <p className="text-[11px] text-slate-400">
                  Real-time 16kHz PCM streaming to Gemini Live
                </p>
              </div>
            </div>
            <div className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-emerald-400" />
              <span>Active</span>
            </div>
          </div>

          {/* Notifications */}
          <div className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 rounded-xl bg-amber-950/60 border border-amber-500/30 text-amber-400">
                <Bell className="w-5 h-5" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-slate-200">Notification Access</h4>
                <p className="text-[11px] text-slate-400">
                  Allow Friday to read incoming message alerts
                </p>
              </div>
            </div>
            <button
              onClick={() => handleToggle('notifications')}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
                perms.notifications
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30'
              }`}
            >
              {perms.notifications ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Granted</span>
                </>
              ) : (
                <>
                  <span>Enable</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </div>

        {/* Bottom CTA */}
        <div className="mt-6 flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 via-sky-500 to-purple-600 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/25 hover:opacity-95 transition-all"
          >
            Ready to Automate
          </button>
        </div>
      </div>
    </div>
  );
};
