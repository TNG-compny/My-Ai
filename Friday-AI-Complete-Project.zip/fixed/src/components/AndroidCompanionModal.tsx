import React, { useState } from 'react';
import { Smartphone, Download, Terminal, Layers, ShieldCheck, Check, Copy, ExternalLink, X, FileCode2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const AndroidCompanionModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  if (!isOpen) return null;

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(id);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="cyber-panel rounded-3xl p-6 w-full max-w-xl border border-cyan-500/40 relative shadow-2xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-400">
              <Smartphone className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 font-display">
                Native Android APK Wrapper
              </h3>
              <p className="text-xs text-slate-400">
                Kotlin Accessibility Service & Native Bridge Architecture
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-xl hover:bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="mt-4 flex-1 overflow-y-auto pr-1 space-y-4">
          {/* Architecture Overview */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-950/30 to-purple-950/20 border border-cyan-500/20 space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-cyan-300">
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>Full-Stack Native Bridge Architecture</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Friday combines the Web Audio frontend with a native Android Accessibility Service in Kotlin. When Gemini Live calls a tool (like playing a YouTube song or sending a WhatsApp message), it calls <code className="text-pink-300 font-mono">window.AndroidBridge</code> which dispatches real accessibility gestures and node clicks directly on the device!
            </p>
          </div>

          {/* Included Kotlin Files */}
          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono">
              Included Android Sources (in /android repository)
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                <div className="font-mono font-bold text-pink-300 flex items-center gap-1.5">
                  <FileCode2 className="w-3.5 h-3.5" />
                  <span>FridayAccessibilityService.kt</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Handles YouTube video clicks, WhatsApp text injection, and Instagram DM gestures.
                </p>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                <div className="font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                  <FileCode2 className="w-3.5 h-3.5" />
                  <span>AndroidBridge.kt</span>
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  Exposes @JavascriptInterface methods to React with zero latency.
                </p>
              </div>
            </div>
          </div>

          {/* Build Instructions */}
          <div className="space-y-2">
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span>Build APK Commands (Android Studio / Gradle)</span>
            </h4>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs space-y-2">
              <div className="flex items-center justify-between text-slate-400 text-[10px]">
                <span>1. Compile Debug APK with Gradle:</span>
                <button
                  onClick={() => copyToClipboard('cd android && ./gradlew assembleDebug', 'build')}
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                >
                  {copiedCmd === 'build' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedCmd === 'build' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <div className="p-2 rounded bg-slate-900/80 text-cyan-300 text-[11px]">
                cd android && ./gradlew assembleDebug
              </div>

              <div className="flex items-center justify-between text-slate-400 text-[10px] pt-1">
                <span>2. Install on Android Phone via ADB:</span>
                <button
                  onClick={() => copyToClipboard('adb install -r android/app/build/outputs/apk/debug/app-debug.apk', 'install')}
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                >
                  {copiedCmd === 'install' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>{copiedCmd === 'install' ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
              <div className="p-2 rounded bg-slate-900/80 text-cyan-300 text-[11px] truncate">
                adb install -r android/app/build/outputs/apk/debug/app-debug.apk
              </div>
            </div>
          </div>

          {/* Setup Checklist */}
          <div className="p-3.5 rounded-2xl bg-slate-900/40 border border-slate-800 space-y-2 text-xs">
            <h5 className="font-semibold text-slate-200">Device Setup Checklist:</h5>
            <ul className="space-y-1.5 text-slate-300 text-[11px]">
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Enable Accessibility in: <strong>Settings &gt; Accessibility &gt; Friday AI Automation</strong></span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Allow <strong>Display Over Other Apps</strong> for floating voice orb overlay</span>
              </li>
              <li className="flex items-center gap-2">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>Grant <strong>Microphone Permission</strong> for continuous audio streaming</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-end shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition-colors"
          >
            Got it, Let's Roll!
          </button>
        </div>
      </div>
    </div>
  );
};
