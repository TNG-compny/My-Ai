import React, { useEffect, useState } from 'react';
import { Mic, MicOff, Zap, Volume2, Sparkles, AlertCircle } from 'lucide-react';
import { AssistantState } from '../types/assistant';
import { audioStreamer } from '../services/audioStreamer';

interface Props {
  state: AssistantState;
  onToggleConnect: () => void;
  voiceName?: string;
}

export const HolographicCore: React.FC<Props> = ({ state, onToggleConnect, voiceName = 'Aoede' }) => {
  const [vol, setVol] = useState(0);

  useEffect(() => {
    const unsubOut = audioStreamer.addOutputVolumeListener((v) => {
      if (state === 'speaking') setVol(v);
    });
    const unsubIn = audioStreamer.addInputVolumeListener((v) => {
      if (state === 'listening') setVol(v);
    });

    return () => {
      unsubOut();
      unsubIn();
    };
  }, [state]);

  const getStatusBadge = () => {
    switch (state) {
      case 'disconnected':
        return {
          label: 'FRIDAY OFFLINE',
          subtext: 'Tap to connect & start voice chat',
          color: 'text-slate-400 border-slate-700 bg-slate-900/60',
          glow: 'from-cyan-500/10 via-purple-500/5 to-transparent',
        };
      case 'connecting':
        return {
          label: 'INITIALIZING QUANTUM LINK',
          subtext: 'Connecting to Gemini Live (PCM16 16k/24k)',
          color: 'text-cyan-400 border-cyan-500/40 bg-cyan-950/40 animate-pulse',
          glow: 'from-cyan-500/30 via-sky-500/20 to-transparent',
        };
      case 'listening':
        return {
          label: 'FRIDAY IS LISTENING',
          subtext: 'Go ahead handsome, talk to me...',
          color: 'text-cyan-300 border-cyan-400/50 bg-cyan-950/60',
          glow: 'from-cyan-500/40 via-blue-500/20 to-transparent',
        };
      case 'thinking':
        return {
          label: 'SYNCHRONIZING THOUGHTS',
          subtext: 'Processing your request...',
          color: 'text-purple-300 border-purple-400/50 bg-purple-950/60 animate-pulse',
          glow: 'from-purple-500/40 via-pink-500/20 to-transparent',
        };
      case 'speaking':
        return {
          label: `FRIDAY IS SPEAKING • ${voiceName.toUpperCase()}`,
          subtext: 'Sassy, witty & in full control 😉',
          color: 'text-pink-300 border-pink-400/50 bg-pink-950/60',
          glow: 'from-pink-500/50 via-purple-500/30 to-transparent',
        };
      case 'executing_action':
        return {
          label: '⚡ EXECUTING ANDROID AUTOMATION',
          subtext: 'Accessibility Service dispatching native UI events...',
          color: 'text-amber-300 border-amber-400/60 bg-amber-950/60 animate-pulse',
          glow: 'from-amber-500/40 via-orange-500/20 to-transparent',
        };
      case 'error':
        return {
          label: 'CONNECTION INTERRUPTED',
          subtext: 'Tap orb to reconnect or test simulation',
          color: 'text-rose-400 border-rose-500/50 bg-rose-950/60',
          glow: 'from-rose-500/30 via-red-500/10 to-transparent',
        };
    }
  };

  const status = getStatusBadge();
  const dynamicScale = 1 + vol * 0.22;

  return (
    <div className="relative flex flex-col items-center justify-center select-none py-6">
      {/* Outer ambient glow field */}
      <div
        className={`absolute -inset-10 rounded-full bg-gradient-radial ${status.glow} blur-3xl opacity-70 transition-all duration-700 pointer-events-none`}
        style={{
          transform: `scale(${dynamicScale * 1.1})`,
        }}
      />

      {/* Futuristic Concentric Orbital Rings */}
      <div className="relative flex items-center justify-center w-64 h-64 sm:w-72 sm:h-72">
        {/* Ring 1 - Outermost dotted boundary */}
        <div
          className={`absolute inset-0 rounded-full border border-dashed transition-all duration-700 ${
            state === 'speaking'
              ? 'border-pink-500/40 animate-spin-slow'
              : state === 'listening'
              ? 'border-cyan-500/40 animate-spin-reverse'
              : state === 'executing_action'
              ? 'border-amber-400/60 animate-spin-slow'
              : 'border-slate-800'
          }`}
        />

        {/* Ring 2 - Sonic Arc Ring with variable radius */}
        <div
          className={`absolute inset-3 rounded-full border-2 transition-all duration-500 ${
            state === 'speaking'
              ? 'border-t-pink-500 border-r-purple-500 border-b-transparent border-l-transparent animate-spin-reverse glow-magenta'
              : state === 'listening'
              ? 'border-t-cyan-400 border-b-sky-400 border-r-transparent border-l-transparent animate-spin-slow glow-cyan'
              : state === 'executing_action'
              ? 'border-t-amber-400 border-r-yellow-400 border-b-orange-400 border-l-transparent animate-spin-reverse'
              : 'border-slate-800/80'
          }`}
          style={{
            transform: `scale(${1 + vol * 0.15})`,
          }}
        />

        {/* Ring 3 - Holographic HUD tick ring */}
        <div
          className={`absolute inset-7 rounded-full border border-slate-700/50 flex items-center justify-center ${
            state === 'listening' || state === 'speaking' ? 'opacity-100' : 'opacity-40'
          }`}
        >
          <div className="absolute top-1 w-2 h-1 bg-cyan-400/80 rounded-full" />
          <div className="absolute bottom-1 w-2 h-1 bg-pink-400/80 rounded-full" />
          <div className="absolute left-1 w-1 h-2 bg-purple-400/80 rounded-full" />
          <div className="absolute right-1 w-1 h-2 bg-cyan-400/80 rounded-full" />
        </div>

        {/* Center Orb: Interactive Trigger Button */}
        <button
          onClick={onToggleConnect}
          aria-label={state === 'disconnected' ? 'Connect Friday' : 'Disconnect Friday'}
          className={`relative z-10 w-36 h-36 sm:w-40 sm:h-40 rounded-full flex flex-col items-center justify-center cursor-pointer transition-all duration-300 transform active:scale-95 shadow-2xl focus:outline-none ${
            state === 'disconnected'
              ? 'bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border border-slate-700/80 hover:border-cyan-500/60 text-slate-400'
              : state === 'connecting'
              ? 'bg-gradient-to-br from-cyan-950 via-slate-950 to-purple-950 border border-cyan-400/70 text-cyan-300 shadow-cyan-500/30'
              : state === 'listening'
              ? 'bg-gradient-to-br from-cyan-900/60 via-slate-950 to-blue-900/60 border-2 border-cyan-400 text-cyan-200 shadow-cyan-500/40 glow-cyan'
              : state === 'speaking'
              ? 'bg-gradient-to-br from-pink-900/70 via-slate-950 to-purple-900/70 border-2 border-pink-400 text-pink-200 shadow-pink-500/40 glow-magenta'
              : state === 'executing_action'
              ? 'bg-gradient-to-br from-amber-900/70 via-slate-950 to-yellow-900/70 border-2 border-amber-400 text-amber-200 shadow-amber-500/40'
              : 'bg-rose-950/80 border border-rose-500 text-rose-300'
          }`}
          style={{
            transform: `scale(${dynamicScale})`,
          }}
        >
          {/* Inner core pulse sphere */}
          <div
            className={`absolute inset-2 rounded-full transition-opacity duration-500 ${
              state === 'speaking'
                ? 'bg-gradient-to-tr from-pink-500/30 to-purple-500/20 blur-sm animate-pulse'
                : state === 'listening'
                ? 'bg-gradient-to-tr from-cyan-500/30 to-blue-500/20 blur-sm animate-pulse'
                : 'opacity-0'
            }`}
          />

          {/* Central Icon */}
          <div className="relative z-20 flex flex-col items-center">
            {state === 'disconnected' && (
              <>
                <MicOff className="w-10 h-10 mb-1 opacity-70 group-hover:opacity-100 transition-opacity" />
                <span className="text-[11px] font-semibold tracking-wider text-slate-300 uppercase">
                  Tap to Start
                </span>
              </>
            )}

            {state === 'connecting' && (
              <>
                <Sparkles className="w-10 h-10 mb-1 animate-spin text-cyan-400" />
                <span className="text-[11px] font-semibold tracking-wider text-cyan-300 uppercase">
                  Linking...
                </span>
              </>
            )}

            {state === 'listening' && (
              <>
                <Mic className="w-11 h-11 mb-1 text-cyan-300 animate-pulse" />
                <span className="text-[11px] font-bold tracking-wider text-cyan-200 uppercase">
                  Listening
                </span>
              </>
            )}

            {state === 'speaking' && (
              <>
                <Volume2 className="w-11 h-11 mb-1 text-pink-300 animate-bounce" />
                <span className="text-[11px] font-bold tracking-wider text-pink-200 uppercase">
                  Speaking
                </span>
              </>
            )}

            {state === 'executing_action' && (
              <>
                <Zap className="w-11 h-11 mb-1 text-amber-300 animate-spin" />
                <span className="text-[11px] font-bold tracking-wider text-amber-200 uppercase">
                  Automating
                </span>
              </>
            )}

            {state === 'error' && (
              <>
                <AlertCircle className="w-10 h-10 mb-1 text-rose-400" />
                <span className="text-[11px] font-semibold tracking-wider text-rose-300 uppercase">
                  Retry
                </span>
              </>
            )}
          </div>
        </button>
      </div>

      {/* Sassy Persona & Status Banner */}
      <div className="mt-6 flex flex-col items-center text-center max-w-sm px-4">
        <div
          className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-mono font-medium tracking-wide border shadow-sm ${status.color}`}
        >
          <span className="relative flex h-2 w-2">
            <span
              className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${
                state === 'listening'
                  ? 'bg-cyan-400'
                  : state === 'speaking'
                  ? 'bg-pink-400'
                  : state === 'executing_action'
                  ? 'bg-amber-400'
                  : 'bg-slate-400'
              }`}
            />
            <span
              className={`relative inline-flex rounded-full h-2 w-2 ${
                state === 'listening'
                  ? 'bg-cyan-500'
                  : state === 'speaking'
                  ? 'bg-pink-500'
                  : state === 'executing_action'
                  ? 'bg-amber-500'
                  : 'bg-slate-500'
              }`}
            />
          </span>
          {status.label}
        </div>

        <p className="mt-2 text-sm text-slate-300 font-medium">
          {status.subtext}
        </p>
      </div>
    </div>
  );
};
