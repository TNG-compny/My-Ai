import React, { useState } from 'react';
import { Settings, Volume2, Sparkles, Sliders, Cpu, Check, X } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentVoice: string;
  onSelectVoice: (voice: string) => void;
}

export const SettingsModal: React.FC<Props> = ({ isOpen, onClose, currentVoice, onSelectVoice }) => {
  const [sassyLevel, setSassyLevel] = useState<'moderate' | 'full_sassy' | 'flirty_tease'>('full_sassy');

  if (!isOpen) return null;

  const voices = [
    { id: 'Aoede', name: 'Aoede', tag: 'Sassy & Playful', desc: 'Young, energetic, witty girlfriend tone (Recommended)', female: true },
    { id: 'Kore', name: 'Kore', tag: 'Warm & Confident', desc: 'Supportive, slightly teasing and confident', female: true },
    { id: 'Zephyr', name: 'Zephyr', tag: 'Chill & Direct', desc: 'Cool, laid-back casual speech', female: false },
    { id: 'Puck', name: 'Puck', tag: 'Bubbly & Quick', desc: 'Fast-paced, vibrant and playful', female: false },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="cyber-panel rounded-3xl p-6 w-full max-w-md border border-cyan-500/40 relative shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-400">
              <Settings className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 font-display">
                Friday Persona & Voice
              </h3>
              <p className="text-xs text-slate-400">
                Configure tone, persona, and speech synthesis
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-xl hover:bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Voice Selection */}
        <div className="mt-4 space-y-3">
          <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
            <Volume2 className="w-3.5 h-3.5 text-pink-400" />
            <span>Gemini Live Voice Profile</span>
          </label>

          <div className="space-y-2">
            {voices.map((v) => (
              <div
                key={v.id}
                onClick={() => onSelectVoice(v.id)}
                className={`p-3 rounded-2xl border cursor-pointer transition-all flex items-center justify-between ${
                  currentVoice === v.id
                    ? 'bg-pink-950/40 border-pink-500/60 shadow-lg shadow-pink-500/10'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-slate-200">{v.name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-pink-500/20 text-pink-300 border border-pink-500/30 font-medium">
                      {v.tag}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">{v.desc}</p>
                </div>
                {currentVoice === v.id && (
                  <div className="w-5 h-5 rounded-full bg-pink-500 flex items-center justify-center text-slate-950">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Persona Sassy Level */}
        <div className="mt-5 space-y-2.5">
          <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>Girlfriend Banter & Sassy Intensity</span>
          </label>

          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setSassyLevel('moderate')}
              className={`py-2 px-2 rounded-xl text-xs font-semibold transition-all border ${
                sassyLevel === 'moderate'
                  ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50'
                  : 'bg-slate-900/60 text-slate-400 border-slate-800'
              }`}
            >
              Playful
            </button>
            <button
              onClick={() => setSassyLevel('full_sassy')}
              className={`py-2 px-2 rounded-xl text-xs font-semibold transition-all border ${
                sassyLevel === 'full_sassy'
                  ? 'bg-pink-500/20 text-pink-300 border-pink-500/50'
                  : 'bg-slate-900/60 text-slate-400 border-slate-800'
              }`}
            >
              Sassy (Default)
            </button>
            <button
              onClick={() => setSassyLevel('flirty_tease')}
              className={`py-2 px-2 rounded-xl text-xs font-semibold transition-all border ${
                sassyLevel === 'flirty_tease'
                  ? 'bg-purple-500/20 text-purple-300 border-purple-500/50'
                  : 'bg-slate-900/60 text-slate-400 border-slate-800'
              }`}
            >
              Flirty Tease
            </button>
          </div>
        </div>

        {/* Model Spec Badge */}
        <div className="mt-5 p-3 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-slate-400 font-mono text-[11px]">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span>Model: gemini-3.8-live</span>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
            PCM16 16k / 24k
          </span>
        </div>

        {/* Save button */}
        <div className="mt-5 pt-3 border-t border-slate-800">
          <button
            onClick={onClose}
            className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg shadow-cyan-600/30 transition-all"
          >
            Apply & Return
          </button>
        </div>
      </div>
    </div>
  );
};
