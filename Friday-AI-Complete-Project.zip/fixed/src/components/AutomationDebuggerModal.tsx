import React, { useState } from 'react';
import { Youtube, MessageCircle, Instagram, Smartphone, Volume2, Flashlight, Play, Terminal, CheckCircle2, ChevronRight, X, Sparkles, Layers } from 'lucide-react';
import { nativeBridge } from '../services/nativeBridge';
import { liveSession } from '../services/liveSession';
import { ActionTrace } from '../types/assistant';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const AutomationDebuggerModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [selectedCategory, setSelectedCategory] = useState<'youtube' | 'whatsapp' | 'instagram' | 'system'>('youtube');
  const [songQuery, setSongQuery] = useState('Starboy The Weeknd');
  const [contactName, setContactName] = useState('Sarah Miller');
  const [whatsappMsg, setWhatsappMsg] = useState('Hey Sarah, are we still going to the concert tonight?');
  const [igUser, setIgUser] = useState('design_daily');
  const [igMsg, setIgMsg] = useState('Loved your latest render!');
  const [selectedApp, setSelectedApp] = useState('Spotify');
  const [volumeLevel, setVolumeLevel] = useState<'low' | 'medium' | 'high' | 'max'>('high');

  const [isExecuting, setIsExecuting] = useState(false);
  const [executionLogs, setExecutionLogs] = useState<string[]>([
    '[INIT] Accessibility Service ready',
    '[BRIDGE] window.AndroidBridge bound to com.friday.assistant',
  ]);

  if (!isOpen) return null;

  const log = (msg: string) => {
    setExecutionLogs((prev) => [`[${new Date().toLocaleTimeString()}] ${msg}`, ...prev.slice(0, 40)]);
  };

  const runYouTubeTest = async () => {
    setIsExecuting(true);
    log(`[AUTOMATION] Triggering YouTube search: "${songQuery}"`);
    log('[ACCESSIBILITY] Targeting package com.google.android.youtube');
    log('[ACCESSIBILITY] Querying viewId: menu_item_search -> ACTION_CLICK');
    log(`[ACCESSIBILITY] Querying viewId: search_edit_text -> ACTION_SET_TEXT("${songQuery}")`);
    log('[ACCESSIBILITY] Querying viewId: video_item_layout -> ACTION_CLICK (Auto-Play Video #1)');

    await nativeBridge.executePlayYouTube(songQuery, true);
    setIsExecuting(false);
    log(`[COMPLETE] YouTube deep automation finished for "${songQuery}"`);
  };

  const runWhatsAppTest = async () => {
    setIsExecuting(true);
    log(`[AUTOMATION] Triggering WhatsApp message to ${contactName}`);
    log('[ACCESSIBILITY] Targeting package com.whatsapp');
    log(`[ACCESSIBILITY] Searching contact "${contactName}" -> ACTION_CLICK`);
    log(`[ACCESSIBILITY] Injecting text into com.whatsapp:id/entry -> ACTION_SET_TEXT("${whatsappMsg}")`);
    log('[ACCESSIBILITY] Triggering send button com.whatsapp:id/send -> ACTION_CLICK');

    await nativeBridge.executeSendWhatsApp(contactName, whatsappMsg);
    setIsExecuting(false);
    log(`[COMPLETE] WhatsApp message successfully dispatched to ${contactName}`);
  };

  const runInstagramTest = async () => {
    setIsExecuting(true);
    log(`[AUTOMATION] Triggering Instagram DM to @${igUser}`);
    log('[ACCESSIBILITY] Targeting package com.instagram.android');
    log('[ACCESSIBILITY] Navigating to inbox -> action_bar_inbox_button');
    log(`[ACCESSIBILITY] Finding thread @${igUser}`);
    log(`[ACCESSIBILITY] Injecting text -> row_thread_composer_edittext`);
    log('[ACCESSIBILITY] Triggering send container');

    await nativeBridge.executeSendInstagramDM(igUser, igMsg);
    setIsExecuting(false);
    log(`[COMPLETE] Instagram DM dispatched to @${igUser}`);
  };

  const runSystemAppTest = async () => {
    setIsExecuting(true);
    log(`[AUTOMATION] Launching app: ${selectedApp}`);
    await nativeBridge.executeOpenApp(selectedApp);
    setIsExecuting(false);
    log(`[COMPLETE] ${selectedApp} launch intent dispatched`);
  };

  const runVolumeTest = async () => {
    setIsExecuting(true);
    log(`[HARDWARE] Adjusting AudioManager volume to: ${volumeLevel}`);
    await nativeBridge.executeAdjustVolume(volumeLevel);
    setIsExecuting(false);
    log(`[COMPLETE] Volume set to ${volumeLevel}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="cyber-panel rounded-3xl p-6 w-full max-w-2xl border border-cyan-500/40 relative shadow-2xl max-h-[92vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-cyan-950/80 border border-cyan-500/40 text-cyan-400">
              <Terminal className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-100 font-display flex items-center gap-2">
                <span>Native Automation Console</span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-mono">
                  Accessibility Bridge
                </span>
              </h3>
              <p className="text-xs text-slate-400">
                Inspect and execute deep Android automated actions in real time
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-200 p-1.5 rounded-xl hover:bg-slate-800/80 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="mt-4 flex-1 overflow-y-auto pr-1 space-y-4">
          {/* Navigation Category Tabs */}
          <div className="grid grid-cols-4 gap-2">
            <button
              onClick={() => setSelectedCategory('youtube')}
              className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                selectedCategory === 'youtube'
                  ? 'bg-red-500/20 text-red-300 border border-red-500/50 shadow-lg shadow-red-500/10'
                  : 'bg-slate-900/60 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              <Youtube className="w-4 h-4 text-red-400" />
              <span>YouTube</span>
            </button>

            <button
              onClick={() => setSelectedCategory('whatsapp')}
              className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                selectedCategory === 'whatsapp'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-lg shadow-emerald-500/10'
                  : 'bg-slate-900/60 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              <MessageCircle className="w-4 h-4 text-emerald-400" />
              <span>WhatsApp</span>
            </button>

            <button
              onClick={() => setSelectedCategory('instagram')}
              className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                selectedCategory === 'instagram'
                  ? 'bg-pink-500/20 text-pink-300 border border-pink-500/50 shadow-lg shadow-pink-500/10'
                  : 'bg-slate-900/60 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              <Instagram className="w-4 h-4 text-pink-400" />
              <span>Instagram</span>
            </button>

            <button
              onClick={() => setSelectedCategory('system')}
              className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
                selectedCategory === 'system'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 shadow-lg shadow-cyan-500/10'
                  : 'bg-slate-900/60 text-slate-400 border border-slate-800 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-4 h-4 text-cyan-400" />
              <span>Apps & HW</span>
            </button>
          </div>

          {/* Category Configuration Panels */}
          {selectedCategory === 'youtube' && (
            <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-200">YouTube Deep Automation</span>
                <span className="text-[10px] text-red-400 font-mono">com.google.android.youtube</span>
              </div>
              <div className="space-y-1.5">
                <label className="text-[11px] text-slate-400 font-medium">Song / Artist Search Query</label>
                <input
                  type="text"
                  value={songQuery}
                  onChange={(e) => setSongQuery(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-100 focus:outline-none focus:border-red-400"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <button
                  disabled={isExecuting}
                  onClick={runYouTubeTest}
                  className="flex-1 py-2 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-red-600/30 transition-all"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Execute Auto-Search & Play Video #1</span>
                </button>

                <button
                  onClick={() => nativeBridge.executeLikeVideo()}
                  className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700"
                >
                  Like Video
                </button>
                <button
                  onClick={() => nativeBridge.executeSubscribe()}
                  className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700"
                >
                  Subscribe
                </button>
              </div>
            </div>
          )}

          {selectedCategory === 'whatsapp' && (
            <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-200">WhatsApp Deep Automation</span>
                <span className="text-[10px] text-emerald-400 font-mono">com.whatsapp</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-400 font-medium">Contact Name</label>
                  <input
                    type="text"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-100 focus:outline-none focus:border-emerald-400"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-400 font-medium">Message Body</label>
                  <input
                    type="text"
                    value={whatsappMsg}
                    onChange={(e) => setWhatsappMsg(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-100 focus:outline-none focus:border-emerald-400"
                  />
                </div>
              </div>

              <button
                disabled={isExecuting}
                onClick={runWhatsAppTest}
                className="w-full py-2 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 transition-all"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Search Contact & Send WhatsApp Message</span>
              </button>
            </div>
          )}

          {selectedCategory === 'instagram' && (
            <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-200">Instagram Deep Automation</span>
                <span className="text-[10px] text-pink-400 font-mono">com.instagram.android</span>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-400 font-medium">Instagram Username</label>
                  <div className="flex items-center">
                    <span className="px-2.5 py-2 bg-slate-800 border border-r-0 border-slate-700 text-slate-400 text-xs rounded-l-xl">@</span>
                    <input
                      type="text"
                      value={igUser}
                      onChange={(e) => setIgUser(e.target.value)}
                      className="w-full px-3 py-2 rounded-r-xl bg-slate-950 border border-slate-700 text-sm text-slate-100 focus:outline-none focus:border-pink-400"
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-400 font-medium">Direct Message Content</label>
                  <input
                    type="text"
                    value={igMsg}
                    onChange={(e) => setIgMsg(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-100 focus:outline-none focus:border-pink-400"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  disabled={isExecuting}
                  onClick={runInstagramTest}
                  className="flex-1 py-2 px-4 rounded-xl bg-gradient-to-r from-pink-600 to-purple-600 hover:opacity-95 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-pink-600/30 transition-all"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Send Instagram DM via Accessibility Service</span>
                </button>

                <button
                  onClick={() => nativeBridge.executeOpenApp('Instagram Reels', 'com.instagram.android')}
                  className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs border border-slate-700"
                >
                  Open Reels
                </button>
              </div>
            </div>
          )}

          {selectedCategory === 'system' && (
            <div className="p-4 rounded-2xl bg-slate-900/50 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-slate-200">Device Hardware & App Launching</span>
                <span className="text-[10px] text-cyan-400 font-mono">PackageManager / AudioManager</span>
              </div>

              {/* App Launch */}
              <div className="flex items-center gap-2">
                <select
                  value={selectedApp}
                  onChange={(e) => setSelectedApp(e.target.value)}
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-sm text-slate-200 focus:outline-none focus:border-cyan-400"
                >
                  <option value="Spotify">Spotify (com.spotify.music)</option>
                  <option value="Camera">Google Camera</option>
                  <option value="Settings">System Settings</option>
                  <option value="Chrome">Google Chrome</option>
                  <option value="Netflix">Netflix</option>
                </select>
                <button
                  onClick={runSystemAppTest}
                  className="py-2 px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs flex items-center gap-1.5"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Launch App</span>
                </button>
              </div>

              {/* Volume & Flashlight */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <Volume2 className="w-4 h-4 text-cyan-400" />
                  <select
                    value={volumeLevel}
                    onChange={(e: any) => setVolumeLevel(e.target.value)}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs text-slate-200"
                  >
                    <option value="mute">Mute</option>
                    <option value="low">Low (25%)</option>
                    <option value="medium">Medium (50%)</option>
                    <option value="high">High (80%)</option>
                    <option value="max">Max (100%)</option>
                  </select>
                  <button
                    onClick={runVolumeTest}
                    className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs text-cyan-300 border border-slate-700"
                  >
                    Apply Volume
                  </button>
                </div>

                <div className="flex items-center gap-2">
                  <Flashlight className="w-4 h-4 text-amber-400" />
                  <button
                    onClick={() => nativeBridge.executeToggleFlashlight('on')}
                    className="px-2.5 py-1.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-semibold"
                  >
                    Torch ON
                  </button>
                  <button
                    onClick={() => nativeBridge.executeToggleFlashlight('off')}
                    className="px-2.5 py-1.5 rounded-lg bg-slate-800 text-slate-300 border border-slate-700 text-xs"
                  >
                    OFF
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Live Execution Logs Console */}
          <div className="p-3 rounded-2xl bg-black/90 border border-cyan-500/30 font-mono text-[11px] text-cyan-300/90 space-y-1 max-h-48 overflow-y-auto">
            <div className="text-[10px] text-slate-500 border-b border-slate-800/80 pb-1 flex items-center justify-between">
              <span className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span>Accessibility Node Inspector Feed</span>
              </span>
              <span>{executionLogs.length} events logged</span>
            </div>
            {executionLogs.map((item, idx) => (
              <div key={idx} className="leading-tight py-0.5">
                <span className="text-slate-500">{item.slice(0, 10)}</span>
                <span className="text-cyan-200">{item.slice(10)}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Footer */}
        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between shrink-0">
          <span className="text-[11px] text-slate-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-pink-400" />
            <span>Friday handles voice queries & tool execution automatically.</span>
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-colors"
          >
            Close Inspector
          </button>
        </div>
      </div>
    </div>
  );
};
