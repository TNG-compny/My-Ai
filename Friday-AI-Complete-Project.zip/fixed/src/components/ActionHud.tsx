import React, { useEffect, useState } from 'react';
import { Youtube, MessageCircle, Instagram, Smartphone, CheckCircle2, Loader2, Sparkles, X, ChevronRight, Music } from 'lucide-react';
import { ActionTrace } from '../types/assistant';
import { nativeBridge } from '../services/nativeBridge';

export const ActionHud: React.FC = () => {
  const [activeTrace, setActiveTrace] = useState<ActionTrace | null>(null);
  const [isDismissed, setIsDismissed] = useState(false);

  useEffect(() => {
    const unsubscribe = nativeBridge.subscribe((trace) => {
      setActiveTrace(trace);
      setIsDismissed(false);

      // Auto dismiss after 6.5s if completed
      if (trace.status === 'completed') {
        const timer = setTimeout(() => {
          setIsDismissed(true);
        }, 6500);
        return () => clearTimeout(timer);
      }
    });

    return () => unsubscribe();
  }, []);

  if (!activeTrace || isDismissed) return null;

  const getAppIcon = (app: string) => {
    switch (app) {
      case 'youtube':
        return <Youtube className="w-5 h-5 text-red-400" />;
      case 'whatsapp':
        return <MessageCircle className="w-5 h-5 text-emerald-400" />;
      case 'instagram':
        return <Instagram className="w-5 h-5 text-pink-400" />;
      case 'spotify':
        return <Music className="w-5 h-5 text-green-400" />;
      default:
        return <Smartphone className="w-5 h-5 text-cyan-400" />;
    }
  };

  const getBadgeStyle = (app: string) => {
    switch (app) {
      case 'youtube':
        return 'border-red-500/40 bg-red-950/40 text-red-300';
      case 'whatsapp':
        return 'border-emerald-500/40 bg-emerald-950/40 text-emerald-300';
      case 'instagram':
        return 'border-pink-500/40 bg-pink-950/40 text-pink-300';
      case 'spotify':
        return 'border-green-500/40 bg-green-950/40 text-green-300';
      default:
        return 'border-cyan-500/40 bg-cyan-950/40 text-cyan-300';
    }
  };

  return (
    <div className="fixed top-4 inset-x-4 max-w-md mx-auto z-50 pointer-events-auto transition-all duration-300 transform translate-y-0">
      <div className="cyber-panel rounded-2xl p-4 border border-cyan-500/30 shadow-2xl relative overflow-hidden backdrop-blur-xl">
        {/* Futuristic glowing top bar indicator */}
        <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-cyan-400 via-pink-500 to-purple-500 animate-pulse" />

        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className={`p-2 rounded-xl border ${getBadgeStyle(activeTrace.app)} flex items-center justify-center`}>
              {getAppIcon(activeTrace.app)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono tracking-wider text-cyan-400 uppercase font-semibold">
                  Accessibility Action
                </span>
                <span className="text-slate-500">•</span>
                <span className="text-[10px] font-mono text-slate-400 capitalize">
                  {activeTrace.app}
                </span>
              </div>
              <h4 className="text-sm font-bold text-slate-100 font-display leading-tight">
                {activeTrace.title}
              </h4>
            </div>
          </div>

          <button
            onClick={() => setIsDismissed(true)}
            className="text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800/60 transition-colors"
            title="Dismiss HUD"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Sassy Friday Commentary */}
        {activeTrace.sassyCommentary && (
          <div className="mt-3 px-3 py-2 rounded-xl bg-pink-950/30 border border-pink-500/20 text-xs text-pink-200 flex items-start gap-2">
            <Sparkles className="w-4 h-4 text-pink-400 shrink-0 mt-0.5" />
            <span className="italic leading-relaxed">
              "{activeTrace.sassyCommentary}"
            </span>
          </div>
        )}

        {/* Step-by-Step Native Execution Progress */}
        <div className="mt-3 space-y-1.5 pt-2 border-t border-slate-800/80">
          {activeTrace.steps.map((step, idx) => (
            <div key={step.id || idx} className="flex items-center justify-between text-xs py-0.5">
              <div className="flex items-center gap-2 truncate">
                {step.status === 'done' ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                ) : step.status === 'in_progress' ? (
                  <Loader2 className="w-3.5 h-3.5 text-cyan-400 animate-spin shrink-0" />
                ) : (
                  <div className="w-3.5 h-3.5 rounded-full border border-slate-700 shrink-0" />
                )}
                <span className={step.status === 'done' ? 'text-slate-300' : step.status === 'in_progress' ? 'text-cyan-300 font-medium' : 'text-slate-500'}>
                  {step.title}
                </span>
              </div>
              <span className="text-[10px] font-mono text-slate-400 truncate max-w-[140px]">
                {step.detail}
              </span>
            </div>
          ))}
        </div>

        {/* Accessibility Tree Trace Badge */}
        {activeTrace.simulatedNodeTree && (
          <div className="mt-2.5 pt-2 flex items-center justify-between text-[10px] font-mono text-slate-400 border-t border-slate-800/50">
            <span className="flex items-center gap-1">
              <ChevronRight className="w-3 h-3 text-cyan-400" />
              <span>Bridge: AccessibilityNodeInfo dispatched</span>
            </span>
            <span className="text-emerald-400 font-semibold uppercase">
              {activeTrace.status}
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
