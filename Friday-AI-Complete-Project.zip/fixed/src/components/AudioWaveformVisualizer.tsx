import React, { useEffect, useRef } from 'react';
import { audioStreamer } from '../services/audioStreamer';
import { AssistantState } from '../types/assistant';

interface Props {
  state: AssistantState;
}

export const AudioWaveformVisualizer: React.FC<Props> = ({ state }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const inputVolRef = useRef<number>(0);
  const outputVolRef = useRef<number>(0);

  useEffect(() => {
    const unsubInput = audioStreamer.addInputVolumeListener((vol) => {
      inputVolRef.current = vol;
    });
    const unsubOutput = audioStreamer.addOutputVolumeListener((vol) => {
      outputVolRef.current = vol;
    });

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let phase = 0;

    const render = () => {
      animFrameRef.current = requestAnimationFrame(render);
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const isActive = state === 'listening' || state === 'speaking' || state === 'executing_action';
      const isSpeaking = state === 'speaking';
      const volume = isSpeaking ? outputVolRef.current : inputVolRef.current;
      const dynamicAmp = isActive ? Math.max(12, volume * 70) : 4;

      phase += isSpeaking ? 0.08 : 0.04;

      // Draw multi-layered neon sonic waves
      const waves = [
        { color: 'rgba(6, 182, 212, 0.7)', speed: 1, freq: 0.02, offset: 0, ampMult: 1 },
        { color: 'rgba(236, 72, 153, 0.65)', speed: 1.3, freq: 0.025, offset: Math.PI / 3, ampMult: 0.8 },
        { color: 'rgba(168, 85, 247, 0.55)', speed: 0.8, freq: 0.015, offset: Math.PI / 2, ampMult: 0.6 },
      ];

      for (const w of waves) {
        ctx.beginPath();
        ctx.strokeStyle = w.color;
        ctx.lineWidth = 2;
        ctx.shadowColor = w.color;
        ctx.shadowBlur = 10;

        for (let x = 0; x < width; x += 4) {
          const envelope = Math.sin((x / width) * Math.PI); // Window tapering at edges
          const y = height / 2 + Math.sin(x * w.freq + phase * w.speed + w.offset) * dynamicAmp * envelope * w.ampMult;
          if (x === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
        }
        ctx.stroke();
      }
    };

    render();

    return () => {
      unsubInput();
      unsubOutput();
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [state]);

  return (
    <div className="w-full flex items-center justify-center">
      <canvas
        ref={canvasRef}
        width={320}
        height={60}
        className="w-full max-w-[360px] h-[55px] pointer-events-none opacity-85"
      />
    </div>
  );
};
