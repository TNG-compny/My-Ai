import { AssistantState, ToolCallItem, ToolResponseItem } from '../types/assistant';
import { audioStreamer } from './audioStreamer';
import { nativeBridge } from './nativeBridge';

type StateListener = (state: AssistantState) => void;
type ErrorListener = (errorMsg: string) => void;
type TranscriptListener = (transcript: { speaker: 'user' | 'friday'; text: string }) => void;

class LiveSessionManager {
  private ws: WebSocket | null = null;
  private state: AssistantState = 'disconnected';
  private stateListeners: Set<StateListener> = new Set();
  private errorListeners: Set<ErrorListener> = new Set();
  private transcriptListeners: Set<TranscriptListener> = new Set();

  private isSpeaking = false;
  private isSimulationMode = false;
  private currentVoice = 'Aoede';

  private playbackTimer: any = null;

  constructor() {
    // Continuously stream audio chunks to Gemini Live
    audioStreamer.addAudioChunkListener((base64) => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(JSON.stringify({ type: 'audio', data: base64 }));
      }
    });
  }

  public subscribeState(listener: StateListener): () => void {
    this.stateListeners.add(listener);
    listener(this.state);
    return () => this.stateListeners.delete(listener);
  }

  public subscribeError(listener: ErrorListener): () => void {
    this.errorListeners.add(listener);
    return () => this.errorListeners.delete(listener);
  }

  public subscribeTranscript(listener: TranscriptListener): () => void {
    this.transcriptListeners.add(listener);
    return () => this.transcriptListeners.delete(listener);
  }

  private setState(newState: AssistantState) {
    if (this.state === newState) return;
    this.state = newState;
    for (const listener of this.stateListeners) {
      listener(newState);
    }
  }

  public getState(): AssistantState {
    return this.state;
  }

  public async sendTextMessage(text: string) {
    if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
      const ok = await this.connect();
      if (!ok) return;
    }
    const send = () => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        console.log('[LiveSession] Sending text prompt to Gemini:', text);
        this.ws.send(JSON.stringify({ type: 'text', text }));
        for (const l of this.transcriptListeners) {
          l({ speaker: 'user', text });
        }
      }
    };
    if (this.ws?.readyState === WebSocket.OPEN) {
      send();
    } else {
      setTimeout(send, 600);
    }
  }

  // Connect to Gemini Live Session
  public async connect(): Promise<boolean> {
    if (this.state === 'connecting' || this.state === 'listening' || this.state === 'speaking') {
      return true;
    }

    this.setState('connecting');

    // Start Audio recording first to ensure user media permissions are granted
    const micReady = await audioStreamer.startRecording();
    if (!micReady) {
      this.setState('error');
      this.notifyError('Microphone permission denied or audio device unavailable.');
      return false;
    }

    const configuredServer = this.getConfiguredServerUrl();
    if (!configuredServer) {
      this.setState('error');
      this.notifyError('Friday server URL is not configured. Set FRIDAY_SERVER_URL in the Android build.');
      audioStreamer.stopRecording();
      return false;
    }

    const wsUrl = this.toWebSocketUrl(configuredServer);

    try {
      this.ws = new WebSocket(wsUrl);

      this.ws.onopen = () => {
        console.log('[LiveSession] WebSocket connection open');
      };

      this.ws.onmessage = async (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === 'ready') {
            console.log('[LiveSession] Gemini Live session is ready');
            this.setState('listening');
          }

          if (msg.type === 'warning') {
            console.warn('[LiveSession]', msg.message);
            this.isSimulationMode = true;
            this.setState('listening');
          }

          // Audio chunk from Gemini (24kHz PCM16)
          if (msg.type === 'audio' && msg.data) {
            this.isSpeaking = true;
            this.setState('speaking');
            audioStreamer.playAudioChunk(msg.data);

            if (this.playbackTimer) clearTimeout(this.playbackTimer);
            this.playbackTimer = setTimeout(() => {
              if (!audioStreamer.isCurrentlySpeaking()) {
                this.isSpeaking = false;
                if (this.state === 'speaking') {
                  this.setState('listening');
                }
              }
            }, 800);
          }

          // User interrupted Friday
          if (msg.type === 'interrupted') {
            console.log('[LiveSession] User interrupted Friday');
            audioStreamer.stopPlaybackAndClearQueue();
            this.isSpeaking = false;
            this.setState('listening');
          }

          // Tool call from Gemini
          if (msg.type === 'tool_call' && msg.calls) {
            await this.handleToolCalls(msg.calls);
          }

          if (msg.type === 'text_transcript' && msg.text) {
            for (const l of this.transcriptListeners) {
              l({ speaker: 'friday', text: msg.text });
            }
          }

          if (msg.type === 'error') {
            console.error('[LiveSession] Server error:', msg.message);
            this.notifyError(msg.message);
            this.setState('error');
          }
        } catch (err) {
          console.error('[LiveSession] Error parsing message:', err);
        }
      };

      this.ws.onclose = () => {
        console.log('[LiveSession] WebSocket closed');
        audioStreamer.stopRecording();
        this.setState('disconnected');
      };

      this.ws.onerror = (err) => {
        console.error('[LiveSession] WebSocket encountered an error:', err);
        this.notifyError('Connection to assistant server dropped.');
        this.setState('error');
      };

      return true;
    } catch (err: any) {
      console.error('[LiveSession] Connection exception:', err);
      this.setState('error');
      this.notifyError(err.message || 'Unable to connect to Friday server.');
      return false;
    }
  }

  private getConfiguredServerUrl(): string {
    if (typeof window !== 'undefined' && window.AndroidBridge?.getServerUrl) {
      const nativeUrl = window.AndroidBridge.getServerUrl();
      if (nativeUrl?.trim()) return nativeUrl.trim().replace(/\/$/, '');
    }

    const browserUrl = (import.meta as any).env?.VITE_FRIDAY_SERVER_URL as string | undefined;
    if (browserUrl?.trim()) return browserUrl.trim().replace(/\/$/, '');

    if (typeof window !== 'undefined' && !window.location.protocol.startsWith('file')) {
      return window.location.origin.replace(/\/$/, '');
    }

    return '';
  }

  private toWebSocketUrl(baseUrl: string): string {
    const url = new URL(baseUrl);
    url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
    url.pathname = `${url.pathname.replace(/\/$/, '')}/api/live-stream`;
    return url.toString();
  }

  // Disconnect session
  public disconnect() {
    audioStreamer.stopRecording();
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.setState('disconnected');
  }

  // Tool Call Execution Loop
  private async handleToolCalls(calls: ToolCallItem[]) {
    this.setState('executing_action');
    const responses: ToolResponseItem[] = [];

    for (const call of calls) {
      console.log(`[LiveSession] Executing tool: ${call.name}`, call.args);

      let result: any = { status: 'success' };

      try {
        switch (call.name) {
          case 'playYouTubeSong': {
            const query = call.args.query || 'Starboy';
            const autoPlay = call.args.autoPlayFirstResult ?? true;
            result = await nativeBridge.executePlayYouTube(query, autoPlay);
            break;
          }
          case 'likeCurrentVideo': {
            result = await nativeBridge.executeLikeVideo();
            break;
          }
          case 'subscribeToChannel': {
            result = await nativeBridge.executeSubscribe(call.args.channelName);
            break;
          }
          case 'sendWhatsAppMessage': {
            const contact = call.args.contact || 'Bestie';
            const message = call.args.message || 'Hey! Sent via Friday AI.';
            result = await nativeBridge.executeSendWhatsApp(contact, message);
            break;
          }
          case 'sendInstagramDM': {
            const username = call.args.username || 'friend';
            const message = call.args.message || 'Hey from Friday!';
            result = await nativeBridge.executeSendInstagramDM(username, message);
            break;
          }
          case 'openInstagramReels': {
            result = await nativeBridge.executeOpenApp('Instagram', 'com.instagram.android');
            break;
          }
          case 'openApp': {
            const app = call.args.appName || 'Spotify';
            const pkg = call.args.packageName;
            result = await nativeBridge.executeOpenApp(app, pkg);
            break;
          }
          case 'adjustDeviceVolume': {
            const level = call.args.level || 'medium';
            result = await nativeBridge.executeAdjustVolume(level);
            break;
          }
          case 'toggleFlashlight': {
            const state = call.args.state || 'on';
            result = await nativeBridge.executeToggleFlashlight(state);
            break;
          }
          case 'readScreenContent': {
            result = {
              status: 'success',
              content: 'Currently active app screen inspected. Elements accessible.',
            };
            break;
          }
          case 'takeScreenshot': {
            result = {
              status: 'success',
              message: 'Screenshot captured and stored in Gallery.',
            };
            break;
          }
          default: {
            result = { status: 'unknown_tool', message: `Tool ${call.name} executed` };
          }
        }
      } catch (err: any) {
        console.error(`[LiveSession] Error in tool ${call.name}:`, err);
        result = { status: 'error', error: err.message };
      }

      responses.push({
        id: call.id,
        name: call.name,
        response: {
          output: result,
        },
      });
    }

    // Send tool responses back to Gemini
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      console.log('[LiveSession] Returning tool execution responses to server');
      this.ws.send(
        JSON.stringify({
          type: 'tool_response',
          responses,
        })
      );
    }

    // Set state back to speaking or listening
    setTimeout(() => {
      if (this.state === 'executing_action') {
        this.setState('listening');
      }
    }, 700);
  }

  // Simulated or Direct Voice Command Trigger
  public async simulateVoiceCommand(actionType: 'youtube' | 'whatsapp' | 'instagram' | 'spotify' | 'volume') {
    const commandPrompts: Record<string, string> = {
      youtube: 'Play Starboy by The Weeknd on YouTube',
      whatsapp: 'Send a WhatsApp message to Sarah saying: Are we still meeting at 6 PM tonight?',
      instagram: 'Send an Instagram DM to design_daily saying: Loved your latest post!',
      spotify: 'Open Spotify',
      volume: 'Set the device volume to high',
    };

    const prompt = commandPrompts[actionType] || 'Hello Friday!';

    // If live session is active, let Gemini Live process and vocalize in 24kHz!
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      await this.sendTextMessage(prompt);
      return;
    }

    // Otherwise, connect session first or run offline simulation fallback
    this.setState('executing_action');
    if (actionType === 'youtube') {
      await nativeBridge.executePlayYouTube('Starboy The Weeknd', true);
    } else if (actionType === 'whatsapp') {
      await nativeBridge.executeSendWhatsApp('Sarah Miller', 'Are we still meeting at 6 PM?');
    } else if (actionType === 'instagram') {
      await nativeBridge.executeSendInstagramDM('design_daily', 'Loved your latest post!');
    } else if (actionType === 'spotify') {
      await nativeBridge.executeOpenApp('Spotify', 'com.spotify.music');
    } else if (actionType === 'volume') {
      await nativeBridge.executeAdjustVolume('high');
    }

    // Synthesize sassy audio feedback using SpeechSynthesis if offline
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      const phrases = [
        "Done babe! Don't say your favorite girl doesn't spoil you.",
        "Handled, handsome! You're welcome.",
        "Got that queued up and ready for you honey. What's next?",
      ];
      const phrase = phrases[Math.floor(Math.random() * phrases.length)];
      const utter = new SpeechSynthesisUtterance(phrase);
      utter.rate = 1.05;
      utter.pitch = 1.15;
      window.speechSynthesis.speak(utter);
      this.setState('speaking');
      utter.onend = () => {
        this.setState('listening');
      };
    } else {
      setTimeout(() => this.setState('listening'), 800);
    }
  }

  private notifyError(msg: string) {
    for (const listener of this.errorListeners) {
      listener(msg);
    }
  }
}

export const liveSession = new LiveSessionManager();
