export class AudioStreamer {
  private inputAudioCtx: AudioContext | null = null;
  private outputAudioCtx: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private inputAnalyser: AnalyserNode | null = null;
  private outputAnalyser: AnalyserNode | null = null;

  private nextStartTime = 0;
  private activeSources: AudioBufferSourceNode[] = [];
  private isRecording = false;

  private audioChunkListeners: Set<(base64Pcm: string) => void> = new Set();
  private inputVolumeListeners: Set<(volume: number) => void> = new Set();
  private outputVolumeListeners: Set<(volume: number) => void> = new Set();
  private volumeCheckInterval: any = null;

  constructor() {
    // Lazy initialized on user interaction
  }

  public addAudioChunkListener(cb: (base64Pcm: string) => void): () => void {
    this.audioChunkListeners.add(cb);
    return () => this.audioChunkListeners.delete(cb);
  }

  public addInputVolumeListener(cb: (volume: number) => void): () => void {
    this.inputVolumeListeners.add(cb);
    return () => this.inputVolumeListeners.delete(cb);
  }

  public addOutputVolumeListener(cb: (volume: number) => void): () => void {
    this.outputVolumeListeners.add(cb);
    return () => this.outputVolumeListeners.delete(cb);
  }

  public setCallbacks(callbacks: {
    onAudioChunk?: (base64Pcm: string) => void;
    onInputVolume?: (volume: number) => void;
    onOutputVolume?: (volume: number) => void;
  }) {
    if (callbacks.onAudioChunk) {
      this.audioChunkListeners.add(callbacks.onAudioChunk);
    }
    if (callbacks.onInputVolume) {
      this.inputVolumeListeners.add(callbacks.onInputVolume);
    }
    if (callbacks.onOutputVolume) {
      this.outputVolumeListeners.add(callbacks.onOutputVolume);
    }
  }

  public async startRecording(): Promise<boolean> {
    try {
      if (this.isRecording) return true;

      // 1. Microphone capture at 16kHz
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.inputAudioCtx = new AudioCtx({ sampleRate: 16000 });

      // 2. Playback output at 24kHz (Gemini Live response specification)
      this.outputAudioCtx = new AudioCtx({ sampleRate: 24000 });

      if (this.inputAudioCtx.state === 'suspended') {
        await this.inputAudioCtx.resume();
      }
      if (this.outputAudioCtx.state === 'suspended') {
        await this.outputAudioCtx.resume();
      }

      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      this.sourceNode = this.inputAudioCtx.createMediaStreamSource(this.mediaStream);
      this.inputAnalyser = this.inputAudioCtx.createAnalyser();
      this.inputAnalyser.fftSize = 256;

      this.outputAnalyser = this.outputAudioCtx.createAnalyser();
      this.outputAnalyser.fftSize = 256;

      // ScriptProcessor for raw PCM extraction
      this.processorNode = this.inputAudioCtx.createScriptProcessor(4096, 1, 1);

      this.processorNode.onaudioprocess = (e) => {
        if (!this.isRecording) return;
        const inputData = e.inputBuffer.getChannelData(0);
        const pcm16 = this.floatTo16BitPCM(inputData);
        const base64 = this.arrayBufferToBase64(pcm16.buffer);
        for (const listener of this.audioChunkListeners) {
          try {
            listener(base64);
          } catch (err) {
            console.error('[AudioStreamer] Chunk listener error:', err);
          }
        }
      };

      this.sourceNode.connect(this.inputAnalyser);
      this.sourceNode.connect(this.processorNode);
      this.processorNode.connect(this.inputAudioCtx.destination);

      this.isRecording = true;
      this.nextStartTime = 0;

      // Start volume meter polling
      this.startVolumeMonitoring();

      return true;
    } catch (err) {
      console.error('[AudioStreamer] Failed to initialize microphone:', err);
      return false;
    }
  }

  public stopRecording() {
    this.isRecording = false;
    if (this.volumeCheckInterval) {
      clearInterval(this.volumeCheckInterval);
      this.volumeCheckInterval = null;
    }

    if (this.processorNode) {
      this.processorNode.disconnect();
      this.processorNode = null;
    }

    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((t) => t.stop());
      this.mediaStream = null;
    }

    this.stopPlaybackAndClearQueue();

    if (this.inputAudioCtx) {
      this.inputAudioCtx.close().catch(() => {});
      this.inputAudioCtx = null;
    }
    if (this.outputAudioCtx) {
      this.outputAudioCtx.close().catch(() => {});
      this.outputAudioCtx = null;
    }
  }

  // Plays 24kHz PCM16 audio chunks gaplessly
  public playAudioChunk(base64Pcm: string) {
    if (!this.outputAudioCtx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.outputAudioCtx = new AudioCtx({ sampleRate: 24000 });
    }

    if (this.outputAudioCtx.state === 'suspended') {
      this.outputAudioCtx.resume().catch(() => {});
    }

    try {
      const arrayBuffer = this.base64ToArrayBuffer(base64Pcm);
      const float32Data = this.pcm16ToFloat32(arrayBuffer);

      const audioBuffer = this.outputAudioCtx.createBuffer(1, float32Data.length, 24000);
      audioBuffer.getChannelData(0).set(float32Data);

      const source = this.outputAudioCtx.createBufferSource();
      source.buffer = audioBuffer;

      if (this.outputAnalyser) {
        source.connect(this.outputAnalyser);
        this.outputAnalyser.connect(this.outputAudioCtx.destination);
      } else {
        source.connect(this.outputAudioCtx.destination);
      }

      const currentTime = this.outputAudioCtx.currentTime;
      // Schedule gaplessly
      const startTime = Math.max(currentTime + 0.005, this.nextStartTime);
      source.start(startTime);
      this.nextStartTime = startTime + audioBuffer.duration;

      this.activeSources.push(source);

      source.onended = () => {
        const index = this.activeSources.indexOf(source);
        if (index > -1) {
          this.activeSources.splice(index, 1);
        }
      };
    } catch (err) {
      console.error('[AudioStreamer] Error playing audio chunk:', err);
    }
  }

  // Interruption Handling: Instantly silence playback
  public stopPlaybackAndClearQueue() {
    for (const src of this.activeSources) {
      try {
        src.stop(0);
        src.disconnect();
      } catch (e) {
        // Source might have already finished
      }
    }
    this.activeSources = [];
    if (this.outputAudioCtx) {
      this.nextStartTime = this.outputAudioCtx.currentTime;
    } else {
      this.nextStartTime = 0;
    }
  }

  public isCurrentlySpeaking(): boolean {
    return this.activeSources.length > 0;
  }

  // Volume Monitoring for Visualizer
  private startVolumeMonitoring() {
    const inputDataArray = new Uint8Array(128);
    const outputDataArray = new Uint8Array(128);

    this.volumeCheckInterval = setInterval(() => {
      // 1. Input mic level
      if (this.inputAnalyser && this.inputVolumeListeners.size > 0) {
        this.inputAnalyser.getByteFrequencyData(inputDataArray);
        let sum = 0;
        for (let i = 0; i < inputDataArray.length; i++) {
          sum += inputDataArray[i];
        }
        const avg = sum / inputDataArray.length;
        const normalized = Math.min(1, avg / 120);
        for (const l of this.inputVolumeListeners) {
          l(normalized);
        }
      }

      // 2. Output speech level
      if (this.outputAnalyser && this.outputVolumeListeners.size > 0) {
        if (this.activeSources.length > 0) {
          this.outputAnalyser.getByteFrequencyData(outputDataArray);
          let sum = 0;
          for (let i = 0; i < outputDataArray.length; i++) {
            sum += outputDataArray[i];
          }
          const avg = sum / outputDataArray.length;
          const normalized = Math.min(1, avg / 110);
          for (const l of this.outputVolumeListeners) {
            l(normalized);
          }
        } else {
          for (const l of this.outputVolumeListeners) {
            l(0);
          }
        }
      }
    }, 40);
  }

  // PCM Conversion Helpers
  private floatTo16BitPCM(input: Float32Array): Int16Array {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return output;
  }

  private pcm16ToFloat32(arrayBuffer: ArrayBuffer): Float32Array {
    const int16Array = new Int16Array(arrayBuffer);
    const float32 = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32[i] = int16Array[i] / (int16Array[i] < 0 ? 0x8000 : 0x7fff);
    }
    return float32;
  }

  private arrayBufferToBase64(buffer: ArrayBufferLike): string {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binaryString = window.atob(base64);
    const len = binaryString.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes.buffer;
  }
}

export const audioStreamer = new AudioStreamer();
