# Friday AI keeps JavaScript bridge methods via @JavascriptInterface.
# WebView and AndroidX rules are supplied by their libraries.
