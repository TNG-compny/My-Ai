package com.friday.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject

/**
 * FridayAccessibilityService
 * Deep UI automation service for YouTube, WhatsApp, Instagram, and General Apps.
 */
class FridayAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "FridayAccessibility"
        var instance: FridayAccessibilityService? = null
            private set

        val isServiceRunning: Boolean
            get() = instance != null
    }

    private val handler = Handler(Looper.getMainLooper())

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "FridayAccessibilityService connected and ready for automation")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Track window changes and app states if needed
    }

    override fun onInterrupt() {
        Log.w(TAG, "FridayAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.i(TAG, "FridayAccessibilityService destroyed")
    }

    // ==========================================
    // DEEP AUTOMATION: YOUTUBE
    // ==========================================

    fun playYouTubeSong(query: String, autoPlay: Boolean, callback: (Boolean, String) -> Unit) {
        val launchIntent = packageManager.getLaunchIntentForPackage("com.google.android.youtube")
        if (launchIntent == null) {
            callback(false, "YouTube app not installed")
            return
        }

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launchIntent)

        // Give the app time to load foreground window
        handler.postDelayed({
            val root = rootInActiveWindow
            if (root == null) {
                callback(false, "Could not acquire YouTube root window")
                return@postDelayed
            }

            // Step 1: Find search icon or button
            val searchButtons = root.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/menu_item_search")
            val targetSearchBtn = if (searchButtons.isNotEmpty()) {
                searchButtons[0]
            } else {
                findNodeByTextOrDescription(root, "Search")
            }

            if (targetSearchBtn != null) {
                performClick(targetSearchBtn)
                
                // Step 2: Inject search query
                handler.postDelayed({
                    val searchEditRoot = rootInActiveWindow ?: return@postDelayed
                    val searchBox = searchEditRoot.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/search_edit_text")
                        .firstOrNull() ?: findEditableNode(searchEditRoot)

                    if (searchBox != null) {
                        val arguments = Bundle()
                        arguments.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, query)
                        searchBox.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)

                        // Trigger search query submit (click search keyboard action or first suggestion)
                        handler.postDelayed({
                            val updatedRoot = rootInActiveWindow ?: return@postDelayed
                            val firstSuggestion = updatedRoot.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/text").firstOrNull()
                            if (firstSuggestion != null) {
                                performClick(firstSuggestion)
                            } else {
                                performGlobalAction(GLOBAL_ACTION_BACK)
                            }

                            // Step 3: Click first video item directly (not just stay on search results)
                            if (autoPlay) {
                                handler.postDelayed({
                                    val resultsRoot = rootInActiveWindow ?: return@postDelayed
                                    val videoItems = resultsRoot.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/video_item_layout")
                                    val videoThumbnail = resultsRoot.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/thumbnail").firstOrNull()
                                    val targetVideo = videoItems.firstOrNull() ?: videoThumbnail ?: findClickableVideoNode(resultsRoot)

                                    if (targetVideo != null) {
                                        performClick(targetVideo)
                                        callback(true, "Playing '$query' directly on YouTube")
                                    } else {
                                        callback(true, "Searched '$query' on YouTube")
                                    }
                                }, 1400)
                            } else {
                                callback(true, "Searched '$query' on YouTube")
                            }
                        }, 800)
                    } else {
                        callback(false, "Search input field not located")
                    }
                }, 800)
            } else {
                callback(false, "YouTube search button not found in UI")
            }
        }, 1200)
    }

    fun likeCurrentVideo(callback: (Boolean, String) -> Unit) {
        val root = rootInActiveWindow
        if (root == null) {
            callback(false, "Screen window not accessible")
            return
        }

        // Try standard like IDs and descriptions
        val likeBtn = root.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/like_button").firstOrNull()
            ?: root.findAccessibilityNodeInfosByViewId("com.instagram.android:id/row_feed_button_like").firstOrNull()
            ?: findNodeByTextOrDescription(root, "like this video")
            ?: findNodeByTextOrDescription(root, "Like")

        if (likeBtn != null) {
            performClick(likeBtn)
            callback(true, "Liked current video")
        } else {
            // Fallback: double tap center of screen for TikTok / Reels
            doubleTapCenter { success ->
                if (success) callback(true, "Liked video via gesture")
                else callback(false, "Like button could not be reached")
            }
        }
    }

    fun subscribeToChannel(channelName: String?, callback: (Boolean, String) -> Unit) {
        val root = rootInActiveWindow
        if (root == null) {
            callback(false, "Screen window not accessible")
            return
        }

        val subBtn = root.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/subscribe_button").firstOrNull()
            ?: findNodeByTextOrDescription(root, "Subscribe")
            ?: findNodeByTextOrDescription(root, "Subscribed")

        if (subBtn != null) {
            performClick(subBtn)
            callback(true, "Subscribed to channel" + if (!channelName.isNullOrEmpty()) " ($channelName)" else "")
        } else {
            callback(false, "Subscribe button not found on active screen")
        }
    }

    // ==========================================
    // DEEP AUTOMATION: WHATSAPP
    // ==========================================

    fun sendWhatsAppMessage(contact: String, message: String, callback: (Boolean, String) -> Unit) {
        val launchIntent = packageManager.getLaunchIntentForPackage("com.whatsapp")
        if (launchIntent == null) {
            callback(false, "WhatsApp app not installed")
            return
        }

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launchIntent)

        handler.postDelayed({
            val root = rootInActiveWindow
            if (root == null) {
                callback(false, "Could not acquire WhatsApp root window")
                return@postDelayed
            }

            // Search for contact or chat
            val searchBtn = root.findAccessibilityNodeInfosByViewId("com.whatsapp:id/menuitem_search").firstOrNull()
                ?: findNodeByTextOrDescription(root, "Search")

            if (searchBtn != null) {
                performClick(searchBtn)
                handler.postDelayed({
                    val searchRoot = rootInActiveWindow ?: return@postDelayed
                    val searchInput = searchRoot.findAccessibilityNodeInfosByViewId("com.whatsapp:id/search_src_text").firstOrNull()
                        ?: findEditableNode(searchRoot)

                    if (searchInput != null) {
                        val args = Bundle()
                        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, contact)
                        searchInput.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

                        handler.postDelayed({
                            val chatListRoot = rootInActiveWindow ?: return@postDelayed
                            val contactItem = findNodeByTextOrDescription(chatListRoot, contact)
                            if (contactItem != null) {
                                performClick(contactItem)

                                // Inside chat window: type and send message
                                handler.postDelayed({
                                    val chatWindow = rootInActiveWindow ?: return@postDelayed
                                    val messageBox = chatWindow.findAccessibilityNodeInfosByViewId("com.whatsapp:id/entry").firstOrNull()
                                        ?: findEditableNode(chatWindow)

                                    if (messageBox != null) {
                                        val msgArgs = Bundle()
                                        msgArgs.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message)
                                        messageBox.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, msgArgs)

                                        handler.postDelayed({
                                            val finalRoot = rootInActiveWindow ?: return@postDelayed
                                            val sendBtn = finalRoot.findAccessibilityNodeInfosByViewId("com.whatsapp:id/send").firstOrNull()
                                                ?: findNodeByTextOrDescription(finalRoot, "Send")

                                            if (sendBtn != null) {
                                                performClick(sendBtn)
                                                callback(true, "Sent message to $contact: \"$message\"")
                                            } else {
                                                callback(false, "WhatsApp send button not found")
                                            }
                                        }, 400)
                                    } else {
                                        callback(false, "WhatsApp message input entry not found")
                                    }
                                }, 800)
                            } else {
                                callback(false, "Contact '$contact' not found in WhatsApp search")
                            }
                        }, 700)
                    } else {
                        callback(false, "WhatsApp search bar not found")
                    }
                }, 600)
            } else {
                callback(false, "WhatsApp search menu not found")
            }
        }, 1000)
    }

    // ==========================================
    // DEEP AUTOMATION: INSTAGRAM
    // ==========================================

    fun sendInstagramDM(username: String, message: String, callback: (Boolean, String) -> Unit) {
        val launchIntent = packageManager.getLaunchIntentForPackage("com.instagram.android")
        if (launchIntent == null) {
            callback(false, "Instagram app not installed")
            return
        }

        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launchIntent)

        handler.postDelayed({
            val root = rootInActiveWindow ?: return@postDelayed callback(false, "Instagram window not ready")
            val dmBtn = root.findAccessibilityNodeInfosByViewId("com.instagram.android:id/action_bar_inbox_button").firstOrNull()
                ?: findNodeByTextOrDescription(root, "Direct")
                ?: findNodeByTextOrDescription(root, "Messages")

            if (dmBtn != null) {
                performClick(dmBtn)
                handler.postDelayed({
                    val dmRoot = rootInActiveWindow ?: return@postDelayed
                    val searchBox = dmRoot.findAccessibilityNodeInfosByViewId("com.instagram.android:id/action_bar_search_edit_text").firstOrNull()
                        ?: findEditableNode(dmRoot)

                    if (searchBox != null) {
                        val args = Bundle()
                        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, username)
                        searchBox.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)

                        handler.postDelayed({
                            val updatedDmRoot = rootInActiveWindow ?: return@postDelayed
                            val userRow = findNodeByTextOrDescription(updatedDmRoot, username)
                            if (userRow != null) {
                                performClick(userRow)
                                handler.postDelayed({
                                    val threadRoot = rootInActiveWindow ?: return@postDelayed
                                    val msgInput = threadRoot.findAccessibilityNodeInfosByViewId("com.instagram.android:id/row_thread_composer_edittext").firstOrNull()
                                        ?: findEditableNode(threadRoot)

                                    if (msgInput != null) {
                                        val msgArgs = Bundle()
                                        msgArgs.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, message)
                                        msgInput.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, msgArgs)

                                        handler.postDelayed({
                                            val finalThread = rootInActiveWindow ?: return@postDelayed
                                            val sendBtn = finalThread.findAccessibilityNodeInfosByViewId("com.instagram.android:id/row_thread_composer_send_button_container").firstOrNull()
                                                ?: findNodeByTextOrDescription(finalThread, "Send")
                                            if (sendBtn != null) {
                                                performClick(sendBtn)
                                                callback(true, "Sent Instagram DM to @$username: \"$message\"")
                                            } else {
                                                callback(false, "Instagram send button missing")
                                            }
                                        }, 400)
                                    } else {
                                        callback(false, "Instagram DM input not found")
                                    }
                                }, 800)
                            } else {
                                callback(false, "Instagram user @$username not found in results")
                            }
                        }, 700)
                    } else {
                        callback(false, "Instagram DM search box missing")
                    }
                }, 700)
            } else {
                callback(false, "Instagram DM button missing on feed")
            }
        }, 1100)
    }

    // ==========================================
    // UTILITY: SCREEN INSPECTION & GESTURES
    // ==========================================

    fun readScreenContent(): JSONObject {
        val root = rootInActiveWindow ?: return JSONObject().put("error", "Window inaccessible")
        val json = JSONObject()
        val elements = JSONArray()
        collectNodeDetails(root, elements)
        json.put("package", root.packageName?.toString() ?: "unknown")
        json.put("elementCount", elements.length())
        json.put("elements", elements)
        return json
    }

    private fun collectNodeDetails(node: AccessibilityNodeInfo, array: JSONArray) {
        val text = node.text?.toString()
        val desc = node.contentDescription?.toString()
        val viewId = node.viewIdResourceName

        if (!text.isNullOrEmpty() || !desc.isNullOrEmpty() || node.isClickable) {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            val item = JSONObject()
            if (!text.isNullOrEmpty()) item.put("text", text)
            if (!desc.isNullOrEmpty()) item.put("description", desc)
            if (viewId != null) item.put("id", viewId)
            item.put("clickable", node.isClickable)
            item.put("bounds", "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}")
            array.put(item)
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                collectNodeDetails(child, array)
                child.recycle()
            }
        }
    }

    fun doubleTapCenter(callback: (Boolean) -> Unit) {
        val displayMetrics = resources.displayMetrics
        val centerX = displayMetrics.widthPixels / 2f
        val centerY = displayMetrics.heightPixels / 2f

        val path1 = Path().apply { moveTo(centerX, centerY) }
        val stroke1 = GestureDescription.StrokeDescription(path1, 0, 50)
        val stroke2 = GestureDescription.StrokeDescription(path1, 100, 50)

        val gesture = GestureDescription.Builder()
            .addStroke(stroke1)
            .addStroke(stroke2)
            .build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback(false)
            }
        }, null)
    }

    private fun performClick(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun findNodeByTextOrDescription(root: AccessibilityNodeInfo, query: String): AccessibilityNodeInfo? {
        val byText = root.findAccessibilityNodeInfosByText(query)
        if (byText.isNotEmpty()) return byText[0]

        // Manual scan for contentDescription
        return scanForDescription(root, query.lowercase())
    }

    private fun scanForDescription(node: AccessibilityNodeInfo, queryLower: String): AccessibilityNodeInfo? {
        val desc = node.contentDescription?.toString()?.lowercase()
        if (desc != null && desc.contains(queryLower)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                val found = scanForDescription(child, queryLower)
                if (found != null) return found
                child.recycle()
            }
        }
        return null
    }

    private fun findEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                val found = findEditableNode(child)
                if (found != null) return found
                child.recycle()
            }
        }
        return null
    }

    private fun findClickableVideoNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isClickable && (node.text?.isNotEmpty() == true || node.contentDescription?.isNotEmpty() == true)) {
            return node
        }
        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                val found = findClickableVideoNode(child)
                if (found != null) return found
                child.recycle()
            }
        }
        return null
    }
}
