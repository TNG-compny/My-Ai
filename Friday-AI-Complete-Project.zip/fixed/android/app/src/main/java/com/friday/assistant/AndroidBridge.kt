package com.friday.assistant

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView
import org.json.JSONObject
import java.util.concurrent.CompletableFuture

/**
 * AndroidBridge
 * Secure JavaScript Bridge exposed to the React Web Application as window.AndroidBridge
 */
class AndroidBridge(
    private val context: Context,
    private val webView: WebView
) {
    companion object {
        private const val TAG = "FridayAndroidBridge"
    }

    private val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
    private val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    // ==========================================
    // PERMISSIONS CHECK & SYSTEM SETTINGS
    // ==========================================

    @JavascriptInterface
    fun isAccessibilityServiceEnabled(): Boolean {
        return FridayAccessibilityService.isServiceRunning
    }

    @JavascriptInterface
    fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    @JavascriptInterface
    fun hasNotificationPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            notificationManager.areNotificationsEnabled()
        } else {
            true
        }
    }

    @JavascriptInterface
    fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        context.startActivity(intent)
    }

    @JavascriptInterface
    fun openOverlaySettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            ).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        }
    }

    @JavascriptInterface
    fun openNotificationSettings() {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
            putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
        }
        context.startActivity(intent)
    }

    // ==========================================
    // DEEP AUTOMATION BRIDGE METHODS
    // ==========================================

    @JavascriptInterface
    fun playYouTubeSong(query: String, autoPlay: Boolean): String {
        val service = FridayAccessibilityService.instance
        if (service == null) {
            // Fallback: Launch via YouTube search intent if accessibility is pending
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube://results?search_query=" + Uri.encode(query))).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return try {
                context.startActivity(webIntent)
                JSONObject().put("status", "success").put("method", "intent").put("message", "Launched YouTube search via intent").toString()
            } catch (e: Exception) {
                JSONObject().put("status", "error").put("message", "YouTube unavailable: ${e.message}").toString()
            }
        }

        val future = CompletableFuture<String>()
        service.playYouTubeSong(query, autoPlay) { success, message ->
            val res = JSONObject()
                .put("status", if (success) "success" else "error")
                .put("message", message)
                .put("method", "accessibility_service")
            future.complete(res.toString())
        }
        return try {
            future.get()
        } catch (e: Exception) {
            JSONObject().put("status", "error").put("message", e.localizedMessage).toString()
        }
    }

    @JavascriptInterface
    fun sendWhatsAppMessage(contact: String, message: String): String {
        val service = FridayAccessibilityService.instance
        if (service == null) {
            // Intent fallback
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("https://api.whatsapp.com/send?text=${Uri.encode(message)}")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            return try {
                context.startActivity(intent)
                JSONObject().put("status", "success").put("method", "intent").put("message", "Opened WhatsApp send composer").toString()
            } catch (e: Exception) {
                JSONObject().put("status", "error").put("message", "WhatsApp not installed").toString()
            }
        }

        val future = CompletableFuture<String>()
        service.sendWhatsAppMessage(contact, message) { success, resultMsg ->
            future.complete(
                JSONObject()
                    .put("status", if (success) "success" else "error")
                    .put("message", resultMsg)
                    .put("method", "accessibility_service")
                    .toString()
            )
        }
        return try {
            future.get()
        } catch (e: Exception) {
            JSONObject().put("status", "error").put("message", e.localizedMessage).toString()
        }
    }

    @JavascriptInterface
    fun sendInstagramDM(username: String, message: String): String {
        val service = FridayAccessibilityService.instance
        if (service == null) {
            return JSONObject().put("status", "error").put("message", "Accessibility Service must be enabled to automate Instagram").toString()
        }

        val future = CompletableFuture<String>()
        service.sendInstagramDM(username, message) { success, resultMsg ->
            future.complete(
                JSONObject()
                    .put("status", if (success) "success" else "error")
                    .put("message", resultMsg)
                    .put("method", "accessibility_service")
                    .toString()
            )
        }
        return try {
            future.get()
        } catch (e: Exception) {
            JSONObject().put("status", "error").put("message", e.localizedMessage).toString()
        }
    }

    @JavascriptInterface
    fun likeCurrentVideo(): String {
        val service = FridayAccessibilityService.instance
            ?: return JSONObject().put("status", "error").put("message", "Accessibility Service inactive").toString()

        val future = CompletableFuture<String>()
        service.likeCurrentVideo { success, msg ->
            future.complete(JSONObject().put("status", if (success) "success" else "error").put("message", msg).toString())
        }
        return future.get()
    }

    @JavascriptInterface
    fun subscribeToChannel(channelName: String?): String {
        val service = FridayAccessibilityService.instance
            ?: return JSONObject().put("status", "error").put("message", "Accessibility Service inactive").toString()

        val future = CompletableFuture<String>()
        service.subscribeToChannel(channelName) { success, msg ->
            future.complete(JSONObject().put("status", if (success) "success" else "error").put("message", msg).toString())
        }
        return future.get()
    }

    @JavascriptInterface
    fun openApp(packageNameOrName: String): String {
        val pm = context.packageManager
        val pkg = when (packageNameOrName.lowercase()) {
            "youtube" -> "com.google.android.youtube"
            "whatsapp" -> "com.whatsapp"
            "instagram" -> "com.instagram.android"
            "spotify" -> "com.spotify.music"
            "camera" -> "com.google.android.GoogleCamera"
            "chrome" -> "com.android.chrome"
            "settings" -> "com.android.settings"
            else -> packageNameOrName
        }

        val intent = pm.getLaunchIntentForPackage(pkg)
        return if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            JSONObject().put("status", "success").put("package", pkg).toString()
        } else {
            JSONObject().put("status", "error").put("message", "App $pkg not found").toString()
        }
    }

    @JavascriptInterface
    fun adjustVolume(level: String): Boolean {
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = when (level.lowercase()) {
            "mute" -> 0
            "low" -> (maxVol * 0.25).toInt()
            "medium" -> (maxVol * 0.5).toInt()
            "high" -> (maxVol * 0.8).toInt()
            "max" -> maxVol
            else -> (maxVol * 0.6).toInt()
        }
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, AudioManager.FLAG_SHOW_UI)
        return true
    }

    @JavascriptInterface
    fun toggleFlashlight(state: Boolean): Boolean {
        return try {
            val cameraId = cameraManager.cameraIdList[0]
            cameraManager.setTorchMode(cameraId, state)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error toggling flashlight: ${e.message}")
            false
        }
    }

    @JavascriptInterface
    fun readScreenContent(): String {
        val service = FridayAccessibilityService.instance
        return if (service != null) {
            service.readScreenContent().toString()
        } else {
            JSONObject().put("status", "error").put("message", "Accessibility Service inactive").toString()
        }
    }

    @JavascriptInterface
    fun getServerUrl(): String {
        return BuildConfig.FRIDAY_SERVER_URL
    }

    @JavascriptInterface
    fun getDeviceInfo(): String {
        return JSONObject()
            .put("model", Build.MODEL)
            .put("manufacturer", Build.MANUFACTURER)
            .put("androidVersion", Build.VERSION.RELEASE)
            .put("sdkInt", Build.VERSION.SDK_INT)
            .put("isNativeWrapper", true)
            .put("accessibilityActive", FridayAccessibilityService.isServiceRunning)
            .toString()
    }
}
