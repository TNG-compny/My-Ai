# Friday AI Android module

This is a normal Android application module embedded in the repository.

The app bundles the React/Vite `dist` output into `app/src/main/assets` during GitHub Actions. `MainActivity` serves those assets through `WebViewAssetLoader` and exposes `window.AndroidBridge` to the web application.

The native bridge provides permission/settings access and Android automation methods used by the React frontend.
