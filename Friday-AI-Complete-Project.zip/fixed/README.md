# Friday AI — Android + React project

This repository contains the React/Vite Friday AI interface plus a native Android WebView wrapper and Accessibility Service.

## GitHub APK build

The workflow at `.github/workflows/android.yml`:

1. installs the web dependencies with Node 22;
2. builds the Vite frontend;
3. copies `dist/` into `android/app/src/main/assets/`;
4. sets up JDK 17;
5. installs Gradle 8.2.1 on the GitHub runner;
6. assembles `android/app/build/outputs/apk/debug/app-debug.apk`;
7. uploads the APK as the `Friday-AI-debug-apk` artifact.

The workflow does not depend on a checked-in Gradle wrapper, so the repository can be built from GitHub even though the original AI Studio export did not contain wrapper files.

## Voice server URL

The Android app reads `FRIDAY_SERVER_URL` from the Android BuildConfig. In GitHub, create:

**Settings → Secrets and variables → Actions → Variables → New repository variable**

Name it:

`FRIDAY_SERVER_URL`

Set it to the HTTPS base URL of the server running `server.ts`, for example:

`https://your-friday-server.example`

The app converts that base URL to the WebSocket endpoint:

`wss://your-friday-server.example/api/live-stream`

Do not put a Gemini API key in the Android app. Keep `GEMINI_API_KEY` on the server only.

## Android project

The Android module uses:

- application id: `com.friday.assistant`
- compile SDK: 34
- target SDK: 34
- minimum SDK: 26
- Java/Kotlin target: 17
- Android Gradle Plugin: 8.2.2
- Gradle: 8.2.1

The WebView loads the compiled frontend from Android app assets through `WebViewAssetLoader`; it no longer tries to load `https://localhost:3000` on a physical phone.

## Important

Building the APK and running the Gemini Live backend are separate operations. The APK can be built without a server URL, but live voice connection requires a reachable HTTPS/WSS backend URL.
